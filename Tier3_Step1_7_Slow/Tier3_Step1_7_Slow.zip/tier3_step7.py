#!/usr/bin/env python3
"""
Tier 3 Rules Engine - Step 7: Build the Response Payload (POS + Receipt safe)

Per AGDC DTP Tier 3 requirements and Workflow.txt:
- Return line-item discounts
- Return total discount and final amount
- Generate receipt lines (8-10 lines, <=32 chars each)
- Support "Unlocked vs Locked" messaging for Tier 3

Receipt line examples:
- "LOYALTY SAVINGS -$1.00"
- "APP BONUS LOCKED"
- "PAY IN APP TO UNLOCK"
"""

from typing import Dict, List, Optional, Callable
from decimal import Decimal, ROUND_HALF_UP


# --------------------------
# Constants
# --------------------------
MAX_RECEIPT_LINE_LENGTH = 32  # Max characters per receipt line
MAX_RECEIPT_LINES = 10  # Max number of receipt lines


# --------------------------
# Receipt Line Formatting
# --------------------------
def format_currency(amount: float) -> str:
    """Format currency amount with proper sign and 2 decimal places."""
    if amount >= 0:
        return f"${amount:.2f}"
    else:
        return f"-${abs(amount):.2f}"


def truncate_line(text: str, max_length: int = MAX_RECEIPT_LINE_LENGTH) -> str:
    """Truncate text to max length, preserving readability."""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def pad_line(left: str, right: str, max_length: int = MAX_RECEIPT_LINE_LENGTH) -> str:
    """Create a line with left and right text, padded with spaces."""
    available = max_length - len(left) - len(right)
    if available < 1:
        # Truncate left side to fit
        left = left[:max_length - len(right) - 4] + "..."
        available = 1
    return left + " " * available + right


# --------------------------
# Receipt Line Generators
# --------------------------
def generate_loyalty_receipt_lines(
    transaction_summary: Dict,
    rewards: List[Dict],
    customer_eligibility: Dict,
    logger: Optional[Callable[[str], None]] = None
) -> List[str]:
    """
    Generate receipt lines for loyalty discounts.
    
    Args:
        transaction_summary: Output from Step 6 (total_discount, discounts_by_bucket, etc.)
        rewards: List of rewards from Step 6
        customer_eligibility: Customer eligibility flags from Steps 1-2
        logger: Optional logging function
    
    Returns:
        List of receipt line strings (max 32 chars each)
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    log("generate_loyalty_receipt_lines: Building receipt lines")
    
    receipt_lines = []
    discounts_by_bucket = transaction_summary.get("discounts_by_bucket", {})
    total_discount = transaction_summary.get("total_discount", 0.0)
    
    # Header line
    receipt_lines.append("*** LOYALTY REWARDS ***")
    
    # Loyalty discount line
    loyalty_discount = discounts_by_bucket.get("loyalty", 0.0)
    if loyalty_discount > 0:
        line = pad_line("LOYALTY SAVINGS", f"-${loyalty_discount:.2f}")
        receipt_lines.append(truncate_line(line))
        log(f"generate_loyalty_receipt_lines: Added loyalty line: {line}")
    
    # Manufacturer discount line
    manufacturer_discount = discounts_by_bucket.get("manufacturer_coupon", 0.0)
    if manufacturer_discount > 0:
        line = pad_line("MFG COUPON", f"-${manufacturer_discount:.2f}")
        receipt_lines.append(truncate_line(line))
        log(f"generate_loyalty_receipt_lines: Added manufacturer line: {line}")
    
    # Multi-unit discount line (if any)
    multi_unit_discount = discounts_by_bucket.get("multi_unit", 0.0)
    if multi_unit_discount > 0:
        line = pad_line("MULTI-BUY SAVINGS", f"-${multi_unit_discount:.2f}")
        receipt_lines.append(truncate_line(line))
        log(f"generate_loyalty_receipt_lines: Added multi-unit line: {line}")
    
    # Retailer discount line (if any)
    retailer_discount = discounts_by_bucket.get("retailer", 0.0)
    if retailer_discount > 0:
        line = pad_line("STORE SAVINGS", f"-${retailer_discount:.2f}")
        receipt_lines.append(truncate_line(line))
        log(f"generate_loyalty_receipt_lines: Added retailer line: {line}")
    
    # Total savings line
    if total_discount > 0:
        receipt_lines.append("-" * MAX_RECEIPT_LINE_LENGTH)
        line = pad_line("TOTAL SAVINGS", f"-${total_discount:.2f}")
        receipt_lines.append(truncate_line(line))
        log(f"generate_loyalty_receipt_lines: Added total line: {line}")
    
    # Locked rewards messaging (if applicable)
    eaiv_verified = customer_eligibility.get("eaiv_verified", False)
    eligible_for_tier3 = customer_eligibility.get("eligible_for_tier3", False)
    
    # Check for locked rewards (EAIV required but not verified)
    if eligible_for_tier3 and not eaiv_verified:
        receipt_lines.append("")
        receipt_lines.append("APP BONUS AVAILABLE")
        receipt_lines.append("VERIFY ID IN APP TO UNLOCK")
        log("generate_loyalty_receipt_lines: Added locked reward messaging")
    
    # Footer
    receipt_lines.append("************************")
    
    # Limit to max lines
    if len(receipt_lines) > MAX_RECEIPT_LINES:
        receipt_lines = receipt_lines[:MAX_RECEIPT_LINES - 1]
        receipt_lines.append("... MORE SAVINGS ...")
    
    log(f"generate_loyalty_receipt_lines: Generated {len(receipt_lines)} receipt lines")
    return receipt_lines


def generate_no_rewards_receipt_lines(
    reason: str = "No eligible rewards",
    logger: Optional[Callable[[str], None]] = None
) -> List[str]:
    """
    Generate receipt lines when no rewards are applicable.
    
    Args:
        reason: Reason for no rewards
        logger: Optional logging function
    
    Returns:
        List of receipt line strings
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    log(f"generate_no_rewards_receipt_lines: Reason={reason}")
    
    receipt_lines = [
        "*** LOYALTY PROGRAM ***",
        "",
        truncate_line(reason),
        "",
        "THANK YOU FOR SHOPPING!",
    ]
    
    return receipt_lines


# --------------------------
# Reward Description Builders
# --------------------------
def build_reward_short_desc(
    discount_types: List[str],
    amount: float
) -> str:
    """
    Build short reward description for POS (<=32 chars).
    
    Args:
        discount_types: List of discount type names (e.g., ["LOYALTY", "MANUFACTURER"])
        amount: Discount amount
    
    Returns:
        Short description string
    """
    if not discount_types:
        return f"SAVINGS -${amount:.2f}"
    
    # Combine types
    type_str = " + ".join(discount_types)
    desc = f"{type_str} -${amount:.2f}"
    
    return truncate_line(desc)


def build_reward_long_desc(
    discount_types: List[str],
    amount: float,
    product_desc: str = None
) -> str:
    """
    Build long reward description for receipt.
    
    Args:
        discount_types: List of discount type names
        amount: Discount amount
        product_desc: Optional product description
    
    Returns:
        Long description string
    """
    if not discount_types:
        base = "LOYALTY REWARD"
    else:
        base = " + ".join(discount_types) + " REWARD"
    
    if product_desc:
        desc = f"{base}: {product_desc}"
    else:
        desc = base
    
    return truncate_line(desc)


# --------------------------
# Enhanced Reward Builder
# --------------------------
def enhance_rewards_for_response(
    rewards: List[Dict],
    transaction_summary: Dict,
    customer_eligibility: Dict,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Enhance reward structures with better descriptions and receipt formatting.
    
    Args:
        rewards: Raw rewards from Step 6
        transaction_summary: Transaction summary from Step 6
        customer_eligibility: Customer eligibility flags
        logger: Optional logging function
    
    Returns:
        Enhanced rewards list with formatted descriptions
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    log(f"enhance_rewards_for_response: Enhancing {len(rewards)} rewards")
    
    enhanced_rewards = []
    
    for reward in rewards:
        enhanced = reward.copy()
        
        value = float(reward.get("value", 0))
        
        # Determine discount types from reward
        discount_types = []
        short_desc = reward.get("short_desc", "")
        
        if "LOYALTY" in short_desc.upper():
            discount_types.append("LOYALTY")
        if "MANUFACTURER" in short_desc.upper():
            discount_types.append("MFG")
        if "MULTI" in short_desc.upper():
            discount_types.append("MULTI-BUY")
        
        if not discount_types:
            discount_types = ["LOYALTY"]
        
        # Build enhanced descriptions
        enhanced["short_desc"] = build_reward_short_desc(discount_types, value)
        enhanced["long_desc"] = build_reward_long_desc(discount_types, value)
        
        log(f"enhance_rewards_for_response: Reward {reward.get('reward_id')}: short='{enhanced['short_desc']}', long='{enhanced['long_desc']}'")
        
        enhanced_rewards.append(enhanced)
    
    return enhanced_rewards


# --------------------------
# Main Step 7 Function
# --------------------------
def build_response_payload(
    pricing_result: Dict,
    customer_eligibility: Dict,
    validation_result: Dict,
    age_result: Dict,
    logger: Optional[Callable[[str], None]] = None
) -> Dict:
    """
    Build the complete response payload for POS (Step 7).
    
    Args:
        pricing_result: Output from Step 6 (apply_pricing_rules)
        customer_eligibility: Customer eligibility from Steps 1-2
        validation_result: Loyalty ID validation result from Step 1
        age_result: Age verification result from Step 2
        logger: Optional logging function
    
    Returns:
        Dict containing:
        - rewards: Enhanced rewards list for AddReward
        - receipt_lines: Formatted receipt lines
        - transaction_summary: Summary for logging/display
        - response_flags: Flags for response building (age_verified, eaiv_verified, etc.)
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    log("build_response_payload: ========== STEP 7: BUILD RESPONSE ==========")
    
    # Extract data from pricing result
    rewards = pricing_result.get("rewards", [])
    transaction_summary = pricing_result.get("transaction_summary", {})
    line_results = pricing_result.get("line_results", [])
    
    # Build customer eligibility for receipt lines
    customer_elig_for_receipt = {
        "eligible_for_tier3": validation_result.get("eligible_for_tier3", False),
        "eligible_for_cid_fund": validation_result.get("eligible_for_cid_fund", False),
        "eaiv_verified": age_result.get("eaiv_verified", False),
        "age_verified": age_result.get("age_verified", False),
    }
    
    # Enhance rewards with better descriptions
    enhanced_rewards = enhance_rewards_for_response(
        rewards=rewards,
        transaction_summary=transaction_summary,
        customer_eligibility=customer_elig_for_receipt,
        logger=log
    )
    
    # Generate receipt lines
    if rewards:
        receipt_lines = generate_loyalty_receipt_lines(
            transaction_summary=transaction_summary,
            rewards=rewards,
            customer_eligibility=customer_elig_for_receipt,
            logger=log
        )
    else:
        reason = "No eligible rewards"
        if not validation_result.get("eligible_for_tier3", False):
            reason = "Loyalty ID not eligible"
        elif not age_result.get("eligible_for_tier3_incentives", False):
            reason = "Age verification required"
        
        receipt_lines = generate_no_rewards_receipt_lines(reason=reason, logger=log)
    
    # Build response flags
    response_flags = {
        "age_verified": age_result.get("age_verified", False),
        "eaiv_verified": age_result.get("eaiv_verified", False),
        "tier3_eligible": validation_result.get("eligible_for_tier3", False),
        "cid_fund_eligible": validation_result.get("eligible_for_cid_fund", False),
    }
    
    # Build result
    result = {
        "rewards": enhanced_rewards,
        "receipt_lines": receipt_lines,
        "transaction_summary": {
            "total_base_price": transaction_summary.get("total_base_price", 0.0),
            "total_discount": transaction_summary.get("total_discount", 0.0),
            "total_final_price": transaction_summary.get("total_final_price", 0.0),
            "discounts_by_bucket": transaction_summary.get("discounts_by_bucket", {}),
            "line_count": len(line_results),
            "reward_count": len(enhanced_rewards),
        },
        "response_flags": response_flags,
    }
    
    log(f"build_response_payload: Generated {len(enhanced_rewards)} rewards, {len(receipt_lines)} receipt lines")
    log(f"build_response_payload: Total discount=${transaction_summary.get('total_discount', 0):.2f}")
    log("build_response_payload: ========== STEP 7 COMPLETE ==========")
    
    return result