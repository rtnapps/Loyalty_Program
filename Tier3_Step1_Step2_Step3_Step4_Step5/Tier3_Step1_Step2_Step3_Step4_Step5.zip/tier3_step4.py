#!/usr/bin/env python3
"""
Tier 3 Rules Engine - Step 4: Identify Which Discount Types Are Allowed

Per AGDC DTP Tier 3 requirements:
- Categorize discount rules into separate buckets (manufacturer, retailer, loyalty, multi-unit, coupon, etc.)
- Keep buckets separate for correct price calculation, receipt lines, and scan data reporting
- Determine which discount types are applicable for the current transaction
"""

import sqlite3
import os
from datetime import datetime
from typing import Dict, List, Optional, Callable
from decimal import Decimal


# --------------------------
# Configuration
# --------------------------
# Database file path
DB_FILE = "loyalty.db"


# --------------------------
# Database Helper Functions
# --------------------------
def get_db_connection():
    """Get SQLite database connection with timeout for concurrent access"""
    if not os.path.exists(DB_FILE):
        raise FileNotFoundError(f"Database file '{DB_FILE}' not found. Please run 'python init_database.py' first.")
    conn = sqlite3.connect(DB_FILE, timeout=10.0)  # 10 second timeout for concurrent access
    return conn


# --------------------------
# Discount Type Constants
# --------------------------
DISCOUNT_TYPE_MANUFACTURER = "manufacturer"  # AGDC/Altria funded offers
DISCOUNT_TYPE_RETAILER = "retailer"  # Store funded
DISCOUNT_TYPE_LOYALTY = "loyalty"  # CID / app / membership value
DISCOUNT_TYPE_MULTI_UNIT = "multi_unit"  # Buy 2 Save $X / Mix&Match
DISCOUNT_TYPE_MULTI_PACK = "multi_pack"  # Marlboro Multi-Pack Fund (2-pack or 3-pack)
DISCOUNT_TYPE_COUPON = "coupon"  # Digital coupon clipped / redeemed
DISCOUNT_TYPE_OTHER_MANUFACTURER = "other_manufacturer"  # ITG/RJR etc
DISCOUNT_TYPE_TRANSACTION = "transaction"  # Transaction-level discount


# --------------------------
# Discount Identification Functions
# --------------------------
def get_manufacturer_allowances(skuguid_list: List[str], store_id: str = None, logger: Optional[Callable[[str], None]] = None) -> List[Dict]:
    """
    Get manufacturer allowances (AGDC/Altria funded) from loyalty_allowances table.
    
    Args:
        skuguid_list: List of SKUGUIDs from normalized basket
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of allowance dictionaries with discount details
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not skuguid_list:
        log(f"get_manufacturer_allowances: No SKUGUIDs provided")
        return []
    
    log(f"get_manufacturer_allowances: Looking up allowances for {len(skuguid_list)} SKUGUIDs")
    
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Find active allowances that include any of the SKUGUIDs
        # Check if current date is between StartDate and EndDate
        placeholders = ','.join(['?'] * len(skuguid_list))
        query = f"""
            SELECT DISTINCT la.*
            FROM loyalty_allowances la
            INNER JOIN loyalty_allowance_skus las ON la.id = las.allowance_id
            WHERE las.SKUGUID IN ({placeholders})
            AND la.StartDate <= DATE('now')
            AND la.EndDate >= DATE('now')
        """
        
        cursor.execute(query, skuguid_list)
        rows = cursor.fetchall()
        conn.close()
        
        allowances = []
        for row in rows:
            # Parse EligibleUOM (comma-separated string)
            eligible_uom = []
            if row["EligibleUOM"]:
                eligible_uom = [uom.strip() for uom in row["EligibleUOM"].split(",") if uom.strip()]
            
            allowance = {
                "discount_type": DISCOUNT_TYPE_MANUFACTURER,
                "allowance_id": row["id"],
                "allowance_type": row["AllowanceType"],
                "promotion_code": row["LoyaltyFundPromotionCode"],
                "amount": float(row["Amount"]) if row["Amount"] else 0.0,
                "currency": row["Currency"] or "USD",
                "minimum_quantity": row["MinimumQuantity"] or 0,
                "maximum_allowance_per_transaction": float(row["MaximumAllowancePerTransaction"]) if row["MaximumAllowancePerTransaction"] else 0.0,
                "maximum_daily_transactions": row["MaximumDailyTransactionsPerLoyalty"] or 0,
                "manufacturer_funded_amount": float(row["ManufacturerFundedAmount"]) if row["ManufacturerFundedAmount"] else 0.0,
                "eligible_uom": eligible_uom,  # ["CARTON", "PACK"]
                "promotional_upcs_eligible": row["PromotionalUPCsEligible"] or "N",
                "start_date": row["StartDate"],
                "end_date": row["EndDate"],
                "rcn_list": row["RCN"].split(",") if row["RCN"] else [],
            }
            allowances.append(allowance)
            log(f"get_manufacturer_allowances: ✅ Found allowance: {allowance['promotion_code']} (${allowance['amount']:.2f})")
        
        log(f"get_manufacturer_allowances: Found {len(allowances)} active manufacturer allowances")
        return allowances
        
    except Exception as e:
        log(f"get_manufacturer_allowances: ❌ DATABASE ERROR: {e}")
        import traceback
        log(f"get_manufacturer_allowances:   - Traceback: {traceback.format_exc()}")
        return []


def get_multi_pack_discounts(
    normalized_lines: List[Dict],
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Get Marlboro Multi-Pack Fund discounts (2-pack or 3-pack configurations).
    
    Per PM USA RTA requirements:
    - PM USA-funded Promotional Allowance on two or three Marlboro revenue cigarette pack transactions
    - Only available for Marlboro revenue cigarettes (excluding Product Promotions)
    - Must detect 2-pack or 3-pack configurations
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of multi-pack discount dictionaries with:
        - discount_type: "multi_pack"
        - brand: "Marlboro"
        - pack_configuration: 2 or 3 (number of packs)
        - discount_amount: Per-pack discount amount
        - multi_unit_indicator: "Y" or "N" (for scan data)
        - multi_unit_required_quantity: 2 or 3
        - multi_unit_discount_amount: Total discount amount
        - eligible_upcs: List of UPCs in the multi-pack
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not normalized_lines:
        log(f"get_multi_pack_discounts: No normalized lines provided")
        return []
    
    log(f"get_multi_pack_discounts: Checking for Marlboro multi-pack configurations (2-pack or 3-pack)")
    
    multi_pack_discounts = []
    
    # Group lines by brand and check for Marlboro products
    marlboro_lines = []
    for line in normalized_lines:
        brand = line.get("Brand", "").upper() if line.get("Brand") else ""
        # Check if it's Marlboro brand
        if "MARLBORO" in brand:
            # Check if it's a revenue cigarette (not Product Promotion)
            # Product Promotions typically have IsPromotionalUPC = "Y"
            is_promotional = False
            if line.get("unit_of_measure") == "PACK":
                is_promotional = line.get("PACK_IsPromotionalUPC", "N") == "Y"
            elif line.get("unit_of_measure") == "CARTON":
                is_promotional = line.get("CARTON_IsPromotionalUPC", "N") == "Y"
            
            # Only include revenue cigarettes (exclude Product Promotions)
            if not is_promotional:
                # Only include PACK units (multi-pack is for packs, not cartons)
                if line.get("unit_of_measure") == "PACK":
                    marlboro_lines.append(line)
                    log(f"get_multi_pack_discounts: Found Marlboro revenue pack: UPC={line.get('upc')}, Qty={line.get('quantity')}, Brand={brand}")
    
    if not marlboro_lines:
        log(f"get_multi_pack_discounts: No Marlboro revenue pack products found")
        return []
    
    # Group Marlboro lines by UPC to handle cases where POS sends multiple lines with same UPC
    # (e.g., 2 separate lines with Qty=1 each, instead of 1 line with Qty=2)
    upc_groups = {}
    for line in marlboro_lines:
        upc = line.get("upc")
        if not upc:
            continue
        
        # Safely convert quantity to int (handle both int and string)
        try:
            quantity = int(line.get("quantity", 0))
        except (ValueError, TypeError):
            log(f"get_multi_pack_discounts: ⚠️  Invalid quantity for line: {line.get('quantity')}")
            continue
        
        if upc not in upc_groups:
            upc_groups[upc] = {
                "lines": [],
                "total_quantity": 0,
                "skuguid": line.get("SKUGUID"),
                "unit_price": line.get("unit_price"),
                "line_number": line.get("line_number")
            }
        
        upc_groups[upc]["lines"].append(line)
        upc_groups[upc]["total_quantity"] += quantity
    
    log(f"get_multi_pack_discounts: Grouped {len(marlboro_lines)} lines into {len(upc_groups)} unique UPCs")
    
    # Check for 2-pack or 3-pack configurations
    # A multi-pack configuration means total quantity of 2 or 3 for the same UPC
    # (either single line with Qty=2/3, or multiple lines totaling 2 or 3)
    for upc, group_data in upc_groups.items():
        total_quantity = group_data["total_quantity"]
        skuguid = group_data["skuguid"]
        unit_price = group_data["unit_price"]
        line_number = group_data["line_number"]
        
        log(f"get_multi_pack_discounts: UPC={upc}, Total Qty={total_quantity} (from {len(group_data['lines'])} line(s))")
        
        if total_quantity == 2 or total_quantity == 3:
            log(f"get_multi_pack_discounts: ✅ Found {total_quantity}-pack configuration for Marlboro: UPC={upc}")
            
            # TODO: Lookup multi-pack fund rate from database or configuration
            # For now, return structure with placeholder amounts
            # In production, this should query a multi_pack_fund_rates table or configuration
            
            # Multi-pack discount structure
            multi_pack_discount = {
                "discount_type": DISCOUNT_TYPE_MULTI_PACK,
                "brand": "Marlboro",
                "pack_configuration": total_quantity,  # 2 or 3
                "discount_amount": 0.0,  # TODO: Lookup from multi_pack_fund_rates table
                "currency": "USD",
                "multi_unit_indicator": "Y",  # For scan data reporting
                "multi_unit_required_quantity": total_quantity,  # 2 or 3
                "multi_unit_discount_amount": 0.0,  # TODO: Calculate based on per-pack rate
                "eligible_upcs": [upc],
                "skuguid": skuguid,
                "line_number": line_number,
                "unit_price": unit_price,
                "total_quantity": total_quantity,  # Total quantity across all lines
                "line_count": len(group_data["lines"]),  # Number of lines that make up this multi-pack
                # Store-level fields for scan data
                "store_id": store_id,
                # Note: Actual discount amounts will be calculated in Step 6 based on rates
                "needs_rate_lookup": True  # Flag to indicate rate lookup needed in Step 6
            }
            
            multi_pack_discounts.append(multi_pack_discount)
            log(f"get_multi_pack_discounts: ✅ Added {total_quantity}-pack multi-pack discount for UPC={upc} (from {len(group_data['lines'])} line(s))")
        else:
            log(f"get_multi_pack_discounts: ⚠️  UPC={upc} has Qty={total_quantity} (not 2 or 3, so no multi-pack discount)")
    
    log(f"get_multi_pack_discounts: Found {len(multi_pack_discounts)} multi-pack configurations")
    return multi_pack_discounts


def get_multi_unit_discounts(
    normalized_lines: List[Dict],
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Get multi-unit discounts (Buy 2 Save $X / Mix&Match).
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of multi-unit discount dictionaries
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not normalized_lines:
        log(f"get_multi_unit_discounts: No normalized lines provided")
        return []
    
    log(f"get_multi_unit_discounts: Checking for multi-unit discounts (Buy 2 Save $X / Mix&Match)")
    
    # TODO: Implement multi-unit discount lookup when multi_unit_rules table is created
    # For now, return empty list
    # In production, this should:
    # 1. Query multi_unit_rules table for active rules
    # 2. Match rules to normalized lines based on UPC/SKUGUID
    # 3. Check minimum quantity requirements
    # 4. Return applicable multi-unit discounts
    
    log(f"get_multi_unit_discounts: Multi-unit discount lookup not yet implemented (table not created)")
    return []


def get_retailer_discounts(
    normalized_lines: List[Dict],
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Get retailer-funded discounts (store funded).
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of retailer discount dictionaries
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not normalized_lines:
        log(f"get_retailer_discounts: No normalized lines provided")
        return []
    
    log(f"get_retailer_discounts: Checking for retailer-funded discounts")
    
    # TODO: Implement retailer discount lookup when retailer_discounts table is created
    # For now, return empty list
    # In production, this should:
    # 1. Query retailer_discounts table for active discounts
    # 2. Match discounts to normalized lines based on UPC/SKUGUID
    # 3. Check store eligibility
    # 4. Return applicable retailer discounts
    
    log(f"get_retailer_discounts: Retailer discount lookup not yet implemented (table not created)")
    return []


def get_coupon_discounts(
    normalized_lines: List[Dict],
    loyalty_id: Optional[str] = None,
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Get coupon discounts (digital coupon clipped / redeemed).
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        loyalty_id: Customer loyalty ID (for checking clipped coupons)
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of coupon discount dictionaries
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not normalized_lines:
        log(f"get_coupon_discounts: No normalized lines provided")
        return []
    
    log(f"get_coupon_discounts: Checking for coupon discounts (digital coupons)")
    
    # TODO: Implement coupon lookup when coupon_rules table is created
    # For now, return empty list
    # In production, this should:
    # 1. Query coupon_rules table for active coupons
    # 2. Check if customer has clipped/redeemed the coupon (query customer_coupons table)
    # 3. Match coupons to normalized lines based on UPC/SKUGUID
    # 4. Verify frequency limits
    # 5. Return applicable coupon discounts
    
    log(f"get_coupon_discounts: Coupon discount lookup not yet implemented (table not created)")
    return []


def get_other_manufacturer_discounts(
    normalized_lines: List[Dict],
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Get other manufacturer discounts (ITG/RJR etc).
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of other manufacturer discount dictionaries
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not normalized_lines:
        log(f"get_other_manufacturer_discounts: No normalized lines provided")
        return []
    
    log(f"get_other_manufacturer_discounts: Checking for other manufacturer discounts (ITG/RJR etc)")
    
    # TODO: Implement other manufacturer discount lookup
    # For now, return empty list
    # In production, this should:
    # 1. Query other_manufacturer_discounts table for active discounts
    # 2. Match discounts to normalized lines based on manufacturer/brand
    # 3. Check store eligibility
    # 4. Return applicable other manufacturer discounts
    
    log(f"get_other_manufacturer_discounts: Other manufacturer discount lookup not yet implemented")
    return []


def get_transaction_discounts(
    normalized_lines: List[Dict],
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> List[Dict]:
    """
    Get transaction-level discounts (rare, but possible).
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        store_id: Store ID (optional, for filtering)
        logger: Optional logging function
    
    Returns:
        List of transaction-level discount dictionaries
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not normalized_lines:
        log(f"get_transaction_discounts: No normalized lines provided")
        return []
    
    log(f"get_transaction_discounts: Checking for transaction-level discounts")
    
    # TODO: Implement transaction-level discount lookup
    # For now, return empty list
    # In production, this should:
    # 1. Query transaction_discounts table for active discounts
    # 2. Check transaction-level eligibility (total amount, item count, etc.)
    # 3. Return applicable transaction discounts
    
    log(f"get_transaction_discounts: Transaction-level discount lookup not yet implemented")
    return []


def identify_discount_types(
    normalized_lines: List[Dict],
    customer_eligibility: Dict,
    store_id: Optional[str] = None,
    loyalty_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> Dict:
    """
    Step 4: Identify which discount types are allowed.
    
    Categorizes discount rules into separate buckets:
    - Manufacturer Program Discount (AGDC/Altria funded offers)
    - Retailer-Funded Discount (store funded)
    - Loyalty Discount (CID / app / membership value)
    - Multi-unit discount (Buy 2 Save $X / Mix&Match)
    - Multi-pack discount (Marlboro Multi-Pack Fund - 2-pack or 3-pack)
    - Coupon discount (digital coupon clipped / redeemed)
    - Other manufacturer discount (ITG/RJR etc)
    - Transaction-level discount (rare)
    
    Per PM USA RTA requirements:
    - Discounts must be kept separate for correct price calculation, receipt lines, and scan data reporting
    - Multi-pack discounts must be identified for Marlboro revenue cigarettes (2-pack or 3-pack)
    - All discount types must be reported separately in scan data
    
    Args:
        normalized_lines: List of normalized line items from Step 3
        customer_eligibility: Dict from Step 1-2 with:
            - eligible_for_tier3: bool
            - eligible_for_cid_fund: bool
            - age_verified: bool
            - eaiv_verified: bool
        store_id: Store location ID
        loyalty_id: Customer loyalty ID (for loyalty discounts)
        logger: Optional logging function
    
    Returns dict with:
    - manufacturer_discounts: List of manufacturer allowance discounts (AGDC/Altria funded)
    - retailer_discounts: List of retailer-funded discounts
    - loyalty_discounts: List of loyalty discounts (will be calculated in Step 6)
    - multi_unit_discounts: List of multi-unit discounts (Buy 2 Save $X / Mix&Match)
    - multi_pack_discounts: List of multi-pack discounts (Marlboro 2-pack or 3-pack)
    - coupon_discounts: List of coupon discounts (digital coupons)
    - other_manufacturer_discounts: List of other manufacturer discounts (ITG/RJR etc)
    - transaction_discounts: List of transaction-level discounts
    - total_discounts_found: Total count of all discounts
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    log(f"identify_discount_types: ========== START DISCOUNT TYPE IDENTIFICATION ==========")
    log(f"identify_discount_types: Input - {len(normalized_lines)} normalized lines, store_id={store_id}, loyalty_id={loyalty_id}")
    
    result = {
        "manufacturer_discounts": [],
        "retailer_discounts": [],
        "loyalty_discounts": [],
        "multi_unit_discounts": [],
        "multi_pack_discounts": [],  # Marlboro Multi-Pack Fund (2-pack or 3-pack)
        "coupon_discounts": [],
        "other_manufacturer_discounts": [],
        "transaction_discounts": [],
        "total_discounts_found": 0
    }
    
    if not normalized_lines:
        log(f"identify_discount_types: No normalized lines provided")
        return result
    
    # Extract SKUGUIDs from normalized lines (only for known products)
    skuguid_list = []
    for line in normalized_lines:
        skuguid = line.get("SKUGUID")
        if skuguid and not line.get("is_unknown", False):
            skuguid_list.append(skuguid)
    
    log(f"identify_discount_types: Extracted {len(skuguid_list)} SKUGUIDs from normalized lines")
    
    # ============================================
    # 1. MANUFACTURER PROGRAM DISCOUNTS (AGDC/Altria funded)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING MANUFACTURER DISCOUNTS ==========")
    manufacturer_allowances = get_manufacturer_allowances(skuguid_list, store_id, logger=log)
    
    # Filter allowances based on customer eligibility and rules
    for allowance in manufacturer_allowances:
        # Check if customer is eligible (must pass Step 1-2)
        if not customer_eligibility.get("eligible_for_tier3", False):
            log(f"identify_discount_types: ⚠️  Skipping allowance {allowance['promotion_code']} - customer not Tier 3 eligible")
            continue
        
        # Check if allowance applies to this store (RCN match)
        if store_id and allowance.get("rcn_list"):
            # RCN might be in the list or store_id might match RCN format
            # For now, if RCN list exists, we'll check it (can be enhanced later)
            log(f"identify_discount_types: Allowance {allowance['promotion_code']} has RCN list: {allowance['rcn_list']}")
        
        # Add to manufacturer discounts
        result["manufacturer_discounts"].append(allowance)
        log(f"identify_discount_types: ✅ Added manufacturer discount: {allowance['promotion_code']} (${allowance['amount']:.2f})")
    
    # ============================================
    # 2. RETAILER-FUNDED DISCOUNTS (Store funded)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING RETAILER DISCOUNTS ==========")
    retailer_discounts = get_retailer_discounts(normalized_lines, store_id, logger=log)
    result["retailer_discounts"] = retailer_discounts
    log(f"identify_discount_types: Retailer discounts: {len(retailer_discounts)}")
    
    # ============================================
    # 3. LOYALTY DISCOUNTS (CID / app / membership)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING LOYALTY DISCOUNTS ==========")
    # Loyalty discounts will be calculated in Step 6 based on:
    # - CID fund eligibility
    # - EAIV status
    # - Customer tier/membership
    # For now, just mark that loyalty discounts are available
    if customer_eligibility.get("eligible_for_tier3", False):
        log(f"identify_discount_types: ✅ Customer eligible for loyalty discounts (will calculate in Step 6)")
        # Add placeholder - actual calculation in Step 6
        result["loyalty_discounts"] = [{"type": "tier3_loyalty", "calculated_in_step6": True}]
    else:
        log(f"identify_discount_types: ❌ Customer NOT eligible for loyalty discounts")
    
    # ============================================
    # 4. MULTI-PACK DISCOUNTS (Marlboro Multi-Pack Fund - 2-pack or 3-pack)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING MULTI-PACK DISCOUNTS ==========")
    multi_pack_discounts = get_multi_pack_discounts(normalized_lines, store_id, logger=log)
    result["multi_pack_discounts"] = multi_pack_discounts
    log(f"identify_discount_types: Multi-pack discounts: {len(multi_pack_discounts)}")
    for mp_discount in multi_pack_discounts:
        log(f"identify_discount_types:   - {mp_discount['pack_configuration']}-pack: UPC={mp_discount['eligible_upcs'][0]}")
    
    # ============================================
    # 5. MULTI-UNIT DISCOUNTS (Buy 2 Save $X / Mix&Match)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING MULTI-UNIT DISCOUNTS ==========")
    multi_unit_discounts = get_multi_unit_discounts(normalized_lines, store_id, logger=log)
    result["multi_unit_discounts"] = multi_unit_discounts
    log(f"identify_discount_types: Multi-unit discounts: {len(multi_unit_discounts)}")
    
    # ============================================
    # 6. COUPON DISCOUNTS (Digital coupon clipped / redeemed)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING COUPON DISCOUNTS ==========")
    coupon_discounts = get_coupon_discounts(normalized_lines, loyalty_id, store_id, logger=log)
    result["coupon_discounts"] = coupon_discounts
    log(f"identify_discount_types: Coupon discounts: {len(coupon_discounts)}")
    
    # ============================================
    # 7. OTHER MANUFACTURER DISCOUNTS (ITG/RJR etc)
    # ============================================
    log(f"identify_discount_types: ========== CHECKING OTHER MANUFACTURER DISCOUNTS ==========")
    other_manufacturer_discounts = get_other_manufacturer_discounts(normalized_lines, store_id, logger=log)
    result["other_manufacturer_discounts"] = other_manufacturer_discounts
    log(f"identify_discount_types: Other manufacturer discounts: {len(other_manufacturer_discounts)}")
    
    # ============================================
    # 8. TRANSACTION-LEVEL DISCOUNTS
    # ============================================
    log(f"identify_discount_types: ========== CHECKING TRANSACTION DISCOUNTS ==========")
    transaction_discounts = get_transaction_discounts(normalized_lines, store_id, logger=log)
    result["transaction_discounts"] = transaction_discounts
    log(f"identify_discount_types: Transaction discounts: {len(transaction_discounts)}")
    
    # Calculate total
    result["total_discounts_found"] = (
        len(result["manufacturer_discounts"]) +
        len(result["retailer_discounts"]) +
        len(result["loyalty_discounts"]) +
        len(result["multi_unit_discounts"]) +
        len(result["multi_pack_discounts"]) +
        len(result["coupon_discounts"]) +
        len(result["other_manufacturer_discounts"]) +
        len(result["transaction_discounts"])
    )
    
    log(f"identify_discount_types: ========== DISCOUNT TYPE IDENTIFICATION COMPLETE ==========")
    log(f"identify_discount_types: Manufacturer discounts: {len(result['manufacturer_discounts'])}")
    log(f"identify_discount_types: Retailer discounts: {len(result['retailer_discounts'])}")
    log(f"identify_discount_types: Loyalty discounts: {len(result['loyalty_discounts'])}")
    log(f"identify_discount_types: Multi-unit discounts: {len(result['multi_unit_discounts'])}")
    log(f"identify_discount_types: Multi-pack discounts: {len(result['multi_pack_discounts'])}")
    log(f"identify_discount_types: Coupon discounts: {len(result['coupon_discounts'])}")
    log(f"identify_discount_types: Other manufacturer discounts: {len(result['other_manufacturer_discounts'])}")
    log(f"identify_discount_types: Transaction discounts: {len(result['transaction_discounts'])}")
    log(f"identify_discount_types: Total discounts found: {result['total_discounts_found']}")
    
    return result