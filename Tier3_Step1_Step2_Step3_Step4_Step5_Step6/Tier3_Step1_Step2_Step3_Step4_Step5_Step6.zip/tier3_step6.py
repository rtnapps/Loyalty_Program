#!/usr/bin/env python3
"""
Tier 3 Rules Engine - Step 6: Apply Pricing Rules in the Correct Order

Per AGDC DTP Tier 3 requirements and Workflow.txt:
- Apply loyalty (and manufacturer) discounts only. Multi-pack applied by Gilbarco POS.
- Calculate discount amounts based on eligibility from Step 5
- Respect discount bucket eligibility flags
- Apply final price guardrails

Order of Application (per Workflow.txt):
6A) Base price (POS regular price)
6B) Multi-Unit / Mix&Match rules
6C) Manufacturer digital coupons (RDC / Enhanced RDC)
6D) Loyalty / Tier 3 locked rewards (App-paid or EAIV-only)
6E) Retailer-funded incentives (optional)
6F) Final price guardrails (no negative prices, max caps, rounding)

Note: Single-pack and multi-pack discounts are applied by POS. We identify multi-pack
configs (Step 4) for scan data tagging only; we do NOT calculate or apply multi-pack amounts.
"""

import sqlite3
import os
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, date
from typing import Dict, List, Optional, Callable


# --------------------------
# Configuration
# --------------------------
# Database file path
DB_FILE = "loyalty.db"


# --------------------------
# Database Helper Functions
# --------------------------
def get_db_connection():
    """Get SQLite database connection with timeout for concurrent access"""
    if not os.path.exists(DB_FILE):
        raise FileNotFoundError(f"Database file '{DB_FILE}' not found. Please run 'python init_database.py' first.")
    conn = sqlite3.connect(DB_FILE, timeout=10.0)
    return conn


# --------------------------
# Database Query Functions
# --------------------------
# Note: Multi-pack discounts are applied by Gilbarco POS. We do NOT calculate or apply
# multi-pack amounts here. Multi-pack identification (Step 4) is used for scan data
# tagging only (Multi-Unit Indicator, Multi-Unit Required Qty). Multi-Unit Discount
# Amount in scan data comes from POS.

def lookup_loyalty_discount(
    skuguid: Optional[str] = None,
    store_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None
) -> float:
    """
    Lookup loyalty discount amount from loyalty_allowances table.
    Uses MaximumAllowancePerTransaction from active loyalty allowances.
    
    Args:
        skuguid: SKUGUID of the product (for SKU-specific allowances)
        store_id: Store ID (optional, for future store-specific filtering)
        logger: Optional logging function
    
    Returns:
        MaximumAllowancePerTransaction amount (float), or 0.0 if not found
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        today = date.today().isoformat()
        
        # Query for active loyalty allowance matching SKUGUID
        # If SKUGUID is NULL in allowance, it applies to all products
        # Priority: SKU-specific allowance > NULL SKUGUID (all products)
        if skuguid:
            query = """
                SELECT la.MaximumAllowancePerTransaction, la.SKUGUID, la.LoyaltyFundPromotionCode
                FROM loyalty_allowances la
                LEFT JOIN loyalty_allowance_skus las ON la.id = las.allowance_id
                WHERE la.AllowanceType LIKE '%Loyalty Fund%'
                  AND la.StartDate <= ?
                  AND la.EndDate >= ?
                  AND (las.SKUGUID = ? OR la.SKUGUID IS NULL)
                ORDER BY 
                    CASE WHEN las.SKUGUID = ? THEN 0 ELSE 1 END,  -- Prefer SKU-specific
                    la.StartDate DESC  -- Prefer most recent
                LIMIT 1
            """
            cursor.execute(query, (today, today, skuguid, skuguid))
        else:
            # No SKUGUID provided, look for general allowances (SKUGUID IS NULL)
            query = """
                SELECT la.MaximumAllowancePerTransaction, la.SKUGUID, la.LoyaltyFundPromotionCode
                FROM loyalty_allowances la
                WHERE la.AllowanceType LIKE '%Loyalty Fund%'
                  AND la.StartDate <= ?
                  AND la.EndDate >= ?
                  AND la.SKUGUID IS NULL
                ORDER BY la.StartDate DESC
                LIMIT 1
            """
            cursor.execute(query, (today, today))
        
        row = cursor.fetchone()
        conn.close()
        
        if row and row["MaximumAllowancePerTransaction"]:
            discount_amount = float(row["MaximumAllowancePerTransaction"])
            promo_code = row["LoyaltyFundPromotionCode"] or "N/A"
            log(f"lookup_loyalty_discount: Found MaximumAllowancePerTransaction=${discount_amount:.2f} (PromoCode={promo_code}, SKUGUID={skuguid or 'all'})")
            return discount_amount
        else:
            log(f"lookup_loyalty_discount: ⚠️  No active loyalty allowance found (SKUGUID={skuguid or 'all'})")
            return 0.0
            
    except Exception as e:
        log(f"lookup_loyalty_discount: ❌ DATABASE ERROR: {e}")
        return 0.0


# --------------------------
# Main Pricing Calculation Function
# --------------------------
def apply_pricing_rules(
    normalized_lines: List[Dict],
    categorized_discounts: Dict,
    eligibility_result: Dict,
    customer_eligibility: Dict,
    store_id: Optional[str] = None,
    loyalty_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None,
) -> Dict:
    """
    Apply pricing rules in the correct order (6A-6F).
    
    Inputs:
    - normalized_lines: Output of Step 3 (normalized basket)
    - categorized_discounts: Output of Step 4 (discount types identified)
    - eligibility_result: Output of Step 5 (eligibility flags)
    - customer_eligibility: Customer eligibility from Step 1-2
    - store_id: Store location ID
    - loyalty_id: Customer loyalty ID
    - logger: Optional logging function
    
    Returns:
    - dict with:
      - line_results: List of pricing results per line (base_price, discounts_by_bucket, final_price)
      - transaction_summary: Total discounts, final amount, discount breakdown
      - rewards: List of reward structures for POS response
    """
    
    def log(msg: str):
        if logger:
            logger(msg)
    
    log(f"apply_pricing_rules: ========== START PRICING CALCULATION ==========")
    log(f"apply_pricing_rules: Processing {len(normalized_lines)} normalized lines")
    
    # Get eligibility flags
    eligible_buckets = eligibility_result.get("eligible_discount_buckets", {})
    transaction_flags = eligibility_result.get("transaction_flags", {})
    line_eligibility = {line.get("upc"): flags for flags in eligibility_result.get("line_results", []) 
                        for line in normalized_lines if line.get("upc") == flags.get("upc")}
    
    # Initialize results
    line_results = []
    transaction_discounts = {
        "multi_unit": 0.0,
        "manufacturer_coupon": 0.0,
        "loyalty": 0.0,
        "multi_pack": 0.0,
        "retailer": 0.0,
        "other_manufacturer": 0.0,
        "transaction": 0.0,
    }
    
    # Process each normalized line
    for line in normalized_lines:
        upc = line.get("upc")
        quantity = int(line.get("quantity", 1))
        unit_price = float(line.get("unit_price", 0.0))
        uom = line.get("unit_of_measure", "PACK")
        line_number = line.get("line_number", "1")
        
        log(f"apply_pricing_rules: Processing line: UPC={upc}, Qty={quantity}, UnitPrice=${unit_price:.2f}, UOM={uom}")
        
        # 6A) Base price
        base_price = unit_price
        extended_base_price = base_price * quantity
        
        # Initialize line result (include product info for database storage)
        line_result = {
            "upc": upc,
            "line_number": line_number,
            "quantity": quantity,
            "unit_of_measure": uom,
            "base_unit_price": base_price,
            "base_extended_price": extended_base_price,
            "discounts_by_bucket": {
                "multi_unit": 0.0,
                "manufacturer_coupon": 0.0,
                "loyalty": 0.0,
                "multi_pack": 0.0,
                "retailer": 0.0,
                "other_manufacturer": 0.0,
                "transaction": 0.0,
            },
            "final_unit_price": base_price,
            "final_extended_price": extended_base_price,
            "total_discount": 0.0,
            # Product info for database storage
            "description": line.get("description", ""),
            "category": line.get("category", ""),
            "manufacturer": line.get("manufacturer", ""),
            "SKUGUID": line.get("SKUGUID", ""),
        }
        
        # Get line eligibility flags
        line_flags = line_eligibility.get(upc, {})
        
        # 6B) Multi-Unit / Mix&Match rules
        if eligible_buckets.get("multi_unit", False):
            multi_unit_discounts = categorized_discounts.get("multi_unit_discounts", [])
            for mu_discount in multi_unit_discounts:
                # Check if this line's UPC is eligible
                if upc in mu_discount.get("eligible_upcs", []):
                    discount_amount = float(mu_discount.get("discount_amount", 0.0))
                    line_result["discounts_by_bucket"]["multi_unit"] += discount_amount
                    log(f"apply_pricing_rules: Applied multi-unit discount ${discount_amount:.2f} to UPC={upc}")
        
        # 6C) Manufacturer digital coupons (RDC / Enhanced RDC)
        if eligible_buckets.get("manufacturer", False):
            # Manufacturer allowances from Step 4
            manufacturer_discounts = categorized_discounts.get("manufacturer_discounts", [])
            for mfg_discount in manufacturer_discounts:
                # Check if this line's SKUGUID matches
                if line.get("SKUGUID") in mfg_discount.get("eligible_skuguids", []):
                    discount_amount = float(mfg_discount.get("amount", 0.0))
                    line_result["discounts_by_bucket"]["manufacturer_coupon"] += discount_amount
                    log(f"apply_pricing_rules: Applied manufacturer discount ${discount_amount:.2f} to UPC={upc}")
        
        # Coupon discounts (if separate from manufacturer)
        if eligible_buckets.get("coupon", False):
            coupon_discounts = categorized_discounts.get("coupon_discounts", [])
            for coupon in coupon_discounts:
                if upc in coupon.get("eligible_upcs", []):
                    discount_amount = float(coupon.get("discount_amount", 0.0))
                    line_result["discounts_by_bucket"]["manufacturer_coupon"] += discount_amount
                    log(f"apply_pricing_rules: Applied coupon discount ${discount_amount:.2f} to UPC={upc}")
        
        # 6D) Loyalty / Tier 3 locked rewards
        if eligible_buckets.get("loyalty", False) and transaction_flags.get("tier3_eligible", False):
            # Check if customer is eligible for loyalty discounts
            if customer_eligibility.get("eligible_for_tier3", False):
                # Lookup loyalty discount from loyalty_allowances.MaximumAllowancePerTransaction
                line_skuguid = line.get("SKUGUID")
                loyalty_discount = lookup_loyalty_discount(
                    skuguid=line_skuguid,
                    store_id=store_id,
                    logger=log
                )
                if loyalty_discount > 0:
                    line_result["discounts_by_bucket"]["loyalty"] = loyalty_discount
                    log(f"apply_pricing_rules: Applied loyalty discount ${loyalty_discount:.2f} to UPC={upc} (SKUGUID={line_skuguid})")
        
        # Multi-Pack Fund (PM USA): NOT applied here.
        # Gilbarco POS applies single-pack and multi-pack discounts directly.
        # We only identify multi-pack configs (Step 4) for scan data tagging.
        # Multi-Unit Discount Amount in scan data comes from POS.
        # Keep multi_pack at 0.0 in discounts_by_bucket.

        # 6E) Retailer-funded incentives
        if eligible_buckets.get("retailer", False):
            retailer_discounts = categorized_discounts.get("retailer_discounts", [])
            for retailer_discount in retailer_discounts:
                if upc in retailer_discount.get("eligible_upcs", []):
                    discount_amount = float(retailer_discount.get("discount_amount", 0.0))
                    line_result["discounts_by_bucket"]["retailer"] += discount_amount
                    log(f"apply_pricing_rules: Applied retailer discount ${discount_amount:.2f} to UPC={upc}")
        
        # Other manufacturer discounts
        if eligible_buckets.get("other_manufacturer", False):
            other_mfg_discounts = categorized_discounts.get("other_manufacturer_discounts", [])
            for other_mfg in other_mfg_discounts:
                if upc in other_mfg.get("eligible_upcs", []):
                    discount_amount = float(other_mfg.get("discount_amount", 0.0))
                    line_result["discounts_by_bucket"]["other_manufacturer"] += discount_amount
                    log(f"apply_pricing_rules: Applied other manufacturer discount ${discount_amount:.2f} to UPC={upc}")
        
        # Transaction-level discounts
        if eligible_buckets.get("transaction", False):
            transaction_discount_list = categorized_discounts.get("transaction_discounts", [])
            for tx_discount in transaction_discount_list:
                discount_amount = float(tx_discount.get("discount_amount", 0.0))
                # Transaction discounts are typically split across all lines or applied to total
                # For simplicity, we'll apply proportionally (can be enhanced)
                line_result["discounts_by_bucket"]["transaction"] += discount_amount / len(normalized_lines)
                log(f"apply_pricing_rules: Applied transaction discount ${discount_amount / len(normalized_lines):.2f} to UPC={upc}")
        
        # Calculate total discount for this line
        total_line_discount = sum(line_result["discounts_by_bucket"].values())
        line_result["total_discount"] = total_line_discount
        
        # 6F) Final price guardrails
        # Ensure no negative prices
        final_extended_price = max(0.0, extended_base_price - total_line_discount)
        final_unit_price = final_extended_price / quantity if quantity > 0 else 0.0
        
        # Round to cents (2 decimal places)
        final_extended_price = float(Decimal(final_extended_price).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
        final_unit_price = float(Decimal(final_unit_price).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
        
        line_result["final_extended_price"] = final_extended_price
        line_result["final_unit_price"] = final_unit_price
        
        log(f"apply_pricing_rules: Line result - Base=${extended_base_price:.2f}, Discount=${total_line_discount:.2f}, Final=${final_extended_price:.2f}")
        
        # Accumulate transaction totals
        for bucket, amount in line_result["discounts_by_bucket"].items():
            transaction_discounts[bucket] += amount
        
        line_results.append(line_result)
    
    # Calculate transaction summary
    total_base_price = sum(line["base_extended_price"] for line in line_results)
    total_discount = sum(line["total_discount"] for line in line_results)
    total_final_price = sum(line["final_extended_price"] for line in line_results)
    
    # Build rewards list for POS response
    rewards = []
    for line_result in line_results:
        if line_result["total_discount"] > 0:
            # Reward = loyalty + manufacturer (we apply). Multi-pack applied by POS; not included.
            reward_value = line_result["total_discount"]
            
            # Determine reward description (loyalty-only; manufacturer if applicable)
            discount_types = []
            if line_result["discounts_by_bucket"]["loyalty"] > 0:
                discount_types.append("LOYALTY")
            if line_result["discounts_by_bucket"]["manufacturer_coupon"] > 0:
                discount_types.append("MANUFACTURER")
            
            reward_desc = "RTN LOYALTY REWARD"
            if discount_types:
                reward_desc = " + ".join(discount_types) + " REWARD"
            
            rewards.append({
                "reward_id": f"{line_result['line_number']}-1-B2_S150",  # Format can be enhanced
                "value": f"{reward_value:.2f}",
                "target_line": line_result["line_number"],
                "discount_method": "amountOff",
                "instant": True,
                "limit_type": "quantity",
                "limit_value": str(line_result["quantity"]),
                "short_desc": reward_desc,
                "long_desc": reward_desc,
            })
    
    result = {
        "line_results": line_results,
        "transaction_summary": {
            "total_base_price": total_base_price,
            "total_discount": total_discount,
            "total_final_price": total_final_price,
            "discounts_by_bucket": transaction_discounts,
        },
        "rewards": rewards,
        "store_id": store_id,
        "loyalty_id": loyalty_id,
    }
    
    log(f"apply_pricing_rules: ========== PRICING CALCULATION COMPLETE ==========")
    log(f"apply_pricing_rules: Total base=${total_base_price:.2f}, Total discount=${total_discount:.2f}, Total final=${total_final_price:.2f}")
    log(f"apply_pricing_rules: Generated {len(rewards)} reward(s)")
    
    return result


# --------------------------
# Database Write Functions
# --------------------------
def store_transaction_results(
    transaction_id: str,
    pricing_result: Dict,
    store_id: Optional[str] = None,
    loyalty_id: Optional[str] = None,
    age_verified: bool = False,
    eaiv_verified: bool = False,
    tier3_eligible: bool = False,
    cid_fund_eligible: bool = False,
    logger: Optional[Callable[[str], None]] = None
) -> bool:
    """
    Store pricing calculation results in transactions and transaction_lines tables.
    
    Args:
        transaction_id: Unique transaction identifier
        pricing_result: Output from apply_pricing_rules()
        store_id: Store location ID
        loyalty_id: Customer loyalty ID
        age_verified: Age verification status
        eaiv_verified: EAIV verification status
        tier3_eligible: Tier 3 eligibility status
        cid_fund_eligible: CID fund eligibility status
        logger: Optional logging function
    
    Returns:
        True if successful, False otherwise
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        transaction_summary = pricing_result.get("transaction_summary", {})
        line_results = pricing_result.get("line_results", [])
        
        # Insert transaction header
        cursor.execute("""
            INSERT INTO transactions (
                transaction_id, store_id, loyalty_id, transaction_timestamp,
                total_discount, final_amount,
                age_verified, eaiv_verified, tier3_eligible, cid_fund_eligible
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            transaction_id,
            store_id,
            loyalty_id,
            datetime.now(),
            transaction_summary.get("total_discount", 0.0),
            transaction_summary.get("total_final_price", 0.0),
            int(age_verified),
            int(eaiv_verified),
            int(tier3_eligible),
            int(cid_fund_eligible)
        ))
        
        # Insert transaction lines
        for line_result in line_results:
            # Determine primary discount type for this line
            discounts_by_bucket = line_result.get("discounts_by_bucket", {})
            primary_discount_type = None
            if discounts_by_bucket.get("multi_pack", 0) > 0:
                primary_discount_type = "multi_pack"
            elif discounts_by_bucket.get("manufacturer_coupon", 0) > 0:
                primary_discount_type = "manufacturer"
            elif discounts_by_bucket.get("loyalty", 0) > 0:
                primary_discount_type = "loyalty"
            elif discounts_by_bucket.get("retailer", 0) > 0:
                primary_discount_type = "retailer"
            elif discounts_by_bucket.get("multi_unit", 0) > 0:
                primary_discount_type = "multi_unit"
            elif discounts_by_bucket.get("coupon", 0) > 0:
                primary_discount_type = "coupon"
            else:
                primary_discount_type = "none"
            
            # Get product info from line_result (already included from normalized_lines)
            upc = line_result.get("upc", "")
            description = line_result.get("description", "") or ""
            category = line_result.get("category", "") or ""
            manufacturer = line_result.get("manufacturer", "") or ""
            
            cursor.execute("""
                INSERT INTO transaction_lines (
                    transaction_id, line_number, upc, description,
                    quantity, regular_unit_price, discount_amount, final_unit_price,
                    category, manufacturer, discount_type
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                transaction_id,
                int(line_result.get("line_number", "1")),
                upc,
                description,
                line_result.get("quantity", 1),
                line_result.get("base_unit_price", 0.0),
                line_result.get("total_discount", 0.0),
                line_result.get("final_unit_price", 0.0),
                category,
                manufacturer,
                primary_discount_type
            ))
        
        conn.commit()
        conn.close()
        
        log(f"store_transaction_results: ✅ Stored transaction {transaction_id} with {len(line_results)} line(s)")
        return True
        
    except Exception as e:
        log(f"store_transaction_results: ❌ DATABASE ERROR: {e}")
        if conn:
            conn.rollback()
            conn.close()
        return False