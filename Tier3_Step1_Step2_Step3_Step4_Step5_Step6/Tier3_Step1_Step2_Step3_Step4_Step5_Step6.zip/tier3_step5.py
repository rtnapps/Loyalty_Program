#!/usr/bin/env python3
"""
Tier 3 Rules Engine - Step 5: Determine Eligibility for Each UPC / Discount Bucket

Purpose (PM USA + AGDC context):
- Decide which line items are eligible for which discount buckets BEFORE applying pricing (Step 6).
- Enforce PM USA RTA gating rules that impact whether PM USA-funded allowances can be earned/reported.

Key PM USA RTA rules implemented here (Jan 20, 2026 Doc010PMUSA-RTA):
- Retailer will not earn PM USA Promotional Allowances on more than five (5) transactions/day
  with a single Loyalty ID (manager/store card behavior).
  -> If Step 1 flags the loyalty ID as NOT eligible_for_cid_fund, we treat PM USA-funded buckets
     (LFP Loyalty Funds + Marlboro Multi-Pack Fund) as INELIGIBLE for this transaction.

Notes:
- This step does NOT calculate amounts. It only produces eligibility flags and reasons.
- “Product Promotions” exclusion is approximated using PACK_IsPromotionalUPC/CARTON_IsPromotionalUPC
  from the products master table. A more complete implementation can add explicit “Product Promotion”
  logic once rules/tables exist.
"""

from typing import Dict, List, Optional, Callable


def determine_line_eligibility(
    normalized_lines: List[Dict],
    customer_eligibility: Dict,
    categorized_discounts: Dict,
    store_id: Optional[str] = None,
    loyalty_id: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = None,
) -> Dict:
    """
    Determine eligibility for each normalized line and each discount bucket.

    Inputs:
    - normalized_lines: output of Step 3 (`tier3_step3.normalize_basket`)
    - customer_eligibility: built in app.py from Step 1-2 outputs
      expected keys:
        - eligible_for_tier3 (bool)
        - eligible_for_cid_fund (bool)  # used as proxy for PM USA 5/day cap eligibility
        - eligible_for_tier3_incentives (bool)
    - categorized_discounts: output of Step 4 (`tier3_step4.identify_discount_types`)

    Returns:
    - dict with:
      - transaction_flags: high-level eligibility flags and reasons
      - line_results: list of per-line eligibility dicts (upc, qty, pack/carton, reasons)
      - eligible_discount_buckets: which discount buckets are allowed this transaction
    """

    def log(msg: str):
        if logger:
            logger(msg)

    result = {
        "transaction_flags": {
            "tier3_eligible": bool(customer_eligibility.get("eligible_for_tier3", False)),
            "tier3_incentives_eligible": bool(customer_eligibility.get("eligible_for_tier3_incentives", False)),
            "pmusa_allowances_eligible": True,  # LFP + Multi-Pack
            "reasons": [],
        },
        "eligible_discount_buckets": {
            "manufacturer": True,   # AGDC/PM USA allowances bucket (LFP loyalty funds in our codebase)
            "multi_pack": True,     # PM USA Multi-Pack fund
            "multi_unit": True,
            "coupon": True,
            "retailer": True,
            "loyalty": True,
            "other_manufacturer": True,
            "transaction": True,
        },
        "line_results": [],
        "store_id": store_id,
        "loyalty_id": loyalty_id,
    }

    # Base transaction gating: must be Tier 3 + incentives eligible to apply tobacco digital incentives.
    if not result["transaction_flags"]["tier3_eligible"]:
        result["transaction_flags"]["reasons"].append("Customer not Tier 3 eligible")
    if not result["transaction_flags"]["tier3_incentives_eligible"]:
        result["transaction_flags"]["reasons"].append("Customer not eligible for Tier 3 incentives (age gating)")

    # PM USA RTA gating: >5 transactions/day with same Loyalty ID => no PM USA promotional allowances.
    # We reuse Step 1's `eligible_for_cid_fund` as the same gating signal.
    if not customer_eligibility.get("eligible_for_cid_fund", False):
        result["transaction_flags"]["pmusa_allowances_eligible"] = False
        result["transaction_flags"]["reasons"].append(
            "PM USA allowances ineligible: loyalty ID exceeded 5 transactions/day (manager/store card behavior)"
        )
        # Disable PM USA-funded buckets
        result["eligible_discount_buckets"]["manufacturer"] = False
        result["eligible_discount_buckets"]["multi_pack"] = False

    # Per-line eligibility checks (basic, conservative)
    for line in normalized_lines or []:
        upc = line.get("upc")
        qty = line.get("quantity")
        uom = line.get("unit_of_measure")  # PACK or CARTON
        brand = (line.get("Brand") or "").upper()

        # Promotional UPC exclusion (for PM USA multi-pack + revenue-only handling)
        is_promotional = False
        if uom == "PACK":
            is_promotional = (line.get("PACK_IsPromotionalUPC") or "N") == "Y"
        elif uom == "CARTON":
            is_promotional = (line.get("CARTON_IsPromotionalUPC") or "N") == "Y"

        is_marlboro = "MARLBORO" in brand

        line_flags = {
            "upc": upc,
            "quantity": qty,
            "unit_of_measure": uom,
            "brand": line.get("Brand"),
            "is_promotional_upc": bool(is_promotional),
            "is_marlboro": bool(is_marlboro),
            "eligible_for_pmusa_multi_pack": False,
            "eligible_for_pmusa_lfp_allowance": False,
            "reasons": [],
        }

        # PM USA multi-pack eligibility (Step 4 detects configurations; Step 5 gates them)
        # - must be Marlboro
        # - must be PACK
        # - must NOT be promotional UPC
        # - transaction must be eligible for PM USA allowances
        if result["transaction_flags"]["pmusa_allowances_eligible"]:
            if is_marlboro and uom == "PACK" and not is_promotional:
                line_flags["eligible_for_pmusa_multi_pack"] = True
                line_flags["eligible_for_pmusa_lfp_allowance"] = True
            else:
                if not is_marlboro:
                    line_flags["reasons"].append("Not Marlboro brand (multi-pack not applicable)")
                if uom != "PACK":
                    line_flags["reasons"].append("Not PACK unit (multi-pack requires packs)")
                if is_promotional:
                    line_flags["reasons"].append("Promotional UPC (revenue-only requirement)")
        else:
            line_flags["reasons"].append("Transaction PM USA allowances ineligible (5/day cap)")

        result["line_results"].append(line_flags)

    # Summarize whether Step 4 found multi-pack configs, and if Step 5 allows them
    mp_found = len(categorized_discounts.get("multi_pack_discounts") or [])
    if mp_found and not result["eligible_discount_buckets"]["multi_pack"]:
        result["transaction_flags"]["reasons"].append(
            f"Multi-pack configs detected ({mp_found}) but PM USA multi-pack bucket disabled by eligibility rules"
        )

    log(
        "tier3_step5.determine_line_eligibility: "
        f"store_id={store_id} loyalty_id={loyalty_id} "
        f"pmusa_allowances_eligible={result['transaction_flags']['pmusa_allowances_eligible']} "
        f"lines={len(result['line_results'])} "
        f"multi_pack_found={mp_found}"
    )

    return result