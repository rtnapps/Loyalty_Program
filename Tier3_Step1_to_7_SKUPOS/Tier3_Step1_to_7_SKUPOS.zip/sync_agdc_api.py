#!/usr/bin/env python3
"""
AGDC API Sync Script
Fetches product and allowance data from AGDC API and updates local database
"""

import sqlite3
import os
import requests
import json
from datetime import datetime
from typing import Dict, List, Optional


# --------------------------
# Configuration
# --------------------------
DB_FILE = "loyalty.db"
API_BASE_URL = "https://api.insightsc3m.com/LoyaltyFundAllowances/v1/LoyaltyFundAllowances"
OAUTH_TOKEN_URL = "https://api.insightsc3m.com/altria/oauth2/v2.0/token"

# API Parameters (update these as needed)
API_PARAMS = {
    "operatingCompany": "0004",  # Update with your operating company
    "cycleCode": "202602",  # Update with current cycle code
    "accountNumber": "0000473527" # "0000709486"  # Update with your account number
}

# API Authentication (update these with your credentials)
OCP_APIM_SUBSCRIPTION_KEY = "6c67581f4ad844fbb3948bd324a7d67e"  # Subscription key for data API
OAUTH_SUBSCRIPTION_KEY = "e42134d5244a4a6e966e3785e14d7f88"  # Subscription key for OAuth endpoint (different from data API)
# OAuth2 Credentials (REQUIRED for getting Bearer token)
# Get these from your AGDC API portal/account
OAUTH_CLIENT_ID = "c91a5b8a-4dd5-407c-93b9-63d7ee6bb60b"
OAUTH_CLIENT_SECRET = "a4J8Q~2d8idvLGxKqyyZ01M6_UdDoA_zrm33lbi7"
# Note: OAuth endpoint requires either client_secret or client_assertion for client_credentials grant


# --------------------------
# Database Helper Functions
# --------------------------
def get_db_connection():
    """
    Get SQLite database connection with timeout for concurrent access.
    Enables WAL mode for better write concurrency and performance.
    """
    if not os.path.exists(DB_FILE):
        raise FileNotFoundError(f"Database file '{DB_FILE}' not found. Please run 'python init_database.py' first.")
    conn = sqlite3.connect(DB_FILE, timeout=10.0)
    
    # Enable WAL mode for better concurrency (allows concurrent reads during writes)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=10000")
    except Exception:
        pass
    
    return conn


# --------------------------
# API Functions
# --------------------------
def get_bearer_token() -> Optional[str]:
    """
    Get Bearer token from OAuth2 endpoint.
    
    Returns:
        Bearer token string, or None if error
    """
    print(f"Getting Bearer token from OAuth2 endpoint...")
    print(f"  URL: {OAUTH_TOKEN_URL}")
    
    # Check if required credentials are provided
    if not OAUTH_CLIENT_ID or not OAUTH_CLIENT_SECRET:
        print(f"❌ OAuth credentials missing!")
        print(f"   Please set OAUTH_CLIENT_ID and OAUTH_CLIENT_SECRET in sync_agdc_api.py")
        print(f"   Or provide them as environment variables:")
        print(f"     export OAUTH_CLIENT_ID='your_client_id'")
        print(f"     export OAUTH_CLIENT_SECRET='your_client_secret'")
        print(f"   Or pass token directly as 4th argument:")
        print(f"     python sync_agdc_api.py <opCompany> <cycleCode> <accountNumber> <bearer_token>")
        return None
    
    try:
        # Prepare OAuth2 request
        # OAuth endpoints typically don't need subscription key, but some Azure AD setups do
        # Try without subscription key first (standard OAuth2)
        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        # OAuth2 token request body - client_credentials grant type
        # Azure AD requires client_id and client_secret for client_credentials
        data = {
            "grant_type": "client_credentials",
            "client_id": OAUTH_CLIENT_ID,
            "client_secret": OAUTH_CLIENT_SECRET,
            "scope": "https://api.insightsc3m.com/.default"  # Common scope for Azure AD
        }
        
        print(f"  Request data: grant_type=client_credentials, client_id={OAUTH_CLIENT_ID[:10]}..., client_secret=***")
        print(f"  Trying OAuth without subscription key first...")
        
        response = requests.post(OAUTH_TOKEN_URL, headers=headers, data=data, timeout=30)
        
        # If 401, try with subscription key (OAuth endpoint requires it)
        if response.status_code == 401:
            error_text = response.text
            if "subscription key" in error_text.lower() or "invalid subscription" in error_text.lower():
                print(f"  ⚠️  OAuth endpoint requires subscription key")
                # Use OAuth-specific subscription key (different from data API key)
                oauth_key = OAUTH_SUBSCRIPTION_KEY or OCP_APIM_SUBSCRIPTION_KEY
                headers["Ocp-Apim-Subscription-Key"] = oauth_key
                print(f"  Trying with OAuth subscription key: {oauth_key}")
                response = requests.post(OAUTH_TOKEN_URL, headers=headers, data=data, timeout=30)
            else:
                # 401 but not subscription key error - raise it
                response.raise_for_status()
        
        response.raise_for_status()
        
        token_data = response.json()
        access_token = token_data.get("access_token")
        
        if access_token:
            expires_in = token_data.get("expires_in", 3600)
            token_type = token_data.get("token_type", "Bearer")
            print(f"✅ Successfully obtained {token_type} token (expires in {expires_in} seconds)")
            return access_token
        else:
            print(f"❌ No access_token in OAuth response")
            print(f"   Response: {token_data}")
            return None
            
    except requests.exceptions.HTTPError as e:
        print(f"❌ HTTP Error getting Bearer token: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"   Status Code: {e.response.status_code}")
            error_text = e.response.text
            print(f"   Response: {error_text[:500]}")
            
            # Parse error details
            try:
                error_json = e.response.json()
                error_code = error_json.get("error_codes", [])
                error_desc = error_json.get("error_description", "")
                print(f"\n   Error Details:")
                print(f"   - Error: {error_json.get('error', 'unknown')}")
                if error_code:
                    print(f"   - Error Codes: {error_code}")
                if error_desc:
                    print(f"   - Description: {error_desc[:200]}")
            except:
                pass
            
            if e.response.status_code == 401:
                print(f"\n   💡 Troubleshooting:")
                print(f"   1. Verify OAUTH_CLIENT_ID and OAUTH_CLIENT_SECRET are correct")
                print(f"   2. Check if your OAuth app is registered in Azure AD")
                print(f"   3. Ensure the app has permissions for the API")
                print(f"   4. Verify Ocp-Apim-Subscription-Key is correct")
        return None
    except requests.exceptions.RequestException as e:
        print(f"❌ Error getting Bearer token: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ Error parsing OAuth JSON response: {e}")
        print(f"   Raw response: {response.text[:500] if 'response' in locals() else 'N/A'}")
        return None


def fetch_agdc_data(operating_company: str, cycle_code: str, account_number: str, bearer_token: str = None) -> Optional[Dict]:
    """
    Fetch data from AGDC API.
    
    Args:
        operating_company: Operating company code (e.g., "0004")
        cycle_code: Cycle code (e.g., "202602")
        account_number: Account number (e.g., "0000709486")
        bearer_token: Bearer token for authentication (if None, will fetch automatically)
    
    Returns:
        dict with API response data, or None if error
    """
    # Get bearer token if not provided
    if not bearer_token:
        bearer_token = get_bearer_token()
        if not bearer_token:
            print("❌ Failed to obtain Bearer token. Cannot proceed with API request.")
            return None
    
    url = API_BASE_URL
    params = {
        "operatingCompany": operating_company,
        "cycleCode": cycle_code,
        "accountNumber": account_number
    }
    
    # Try subscription key in header first (most common)
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Ocp-Apim-Subscription-Key": OCP_APIM_SUBSCRIPTION_KEY,
        "Accept": "application/json"
    }
    
    print(f"\nFetching data from AGDC API...")
    print(f"  URL: {url}")
    print(f"  Params: {params}")
    print(f"  Headers: Authorization=Bearer ***, Ocp-Apim-Subscription-Key={OCP_APIM_SUBSCRIPTION_KEY}")
    
    try:
        # First try with subscription key in header
        response = requests.get(url, params=params, headers=headers, timeout=30)
        
        # If 401, try with subscription key as query parameter (some APIs use this)
        if response.status_code == 401:
            print(f"  ⚠️  Header method failed, trying subscription key as query parameter...")
            params_with_key = params.copy()
            params_with_key["subscription-key"] = OCP_APIM_SUBSCRIPTION_KEY
            # Remove subscription key from headers for this attempt
            headers_no_key = {
                "Authorization": f"Bearer {bearer_token}",
                "Accept": "application/json"
            }
            response = requests.get(url, params=params_with_key, headers=headers_no_key, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        print(f"✅ Successfully fetched data from API")
        return data
    except requests.exceptions.HTTPError as e:
        print(f"❌ HTTP Error fetching data from API: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"   Status Code: {e.response.status_code}")
            error_text = e.response.text
            print(f"   Response: {error_text[:500]}")
            
            # Parse error details
            try:
                error_json = e.response.json()
                status_code = error_json.get("statusCode")
                message = error_json.get("message", "")
                print(f"\n   Error Details:")
                if status_code:
                    print(f"   - Status Code: {status_code}")
                if message:
                    print(f"   - Message: {message}")
            except:
                pass
            
            if e.response.status_code == 401:
                print(f"\n   💡 Troubleshooting:")
                print(f"   1. Verify Ocp-Apim-Subscription-Key is correct and matches your API portal")
                print(f"      Current key: {OCP_APIM_SUBSCRIPTION_KEY}")
                print(f"      Key length: {len(OCP_APIM_SUBSCRIPTION_KEY)} characters")
                print(f"   2. Check if subscription key is active and not expired in your API portal")
                print(f"   3. Verify the subscription key is for the correct API endpoint/product")
                print(f"   4. Ensure the subscription key matches the API you're calling")
                print(f"   5. Check if your account has access to this specific API endpoint")
                print(f"   6. Verify Bearer token has correct scopes/permissions for this API")
                print(f"\n   Note: Bearer token was obtained successfully, but subscription key validation failed.")
                print(f"   This suggests the subscription key may be incorrect, expired, or for a different API.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"❌ Error fetching data from API: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ Error parsing JSON response: {e}")
        return None


# --------------------------
# Database Update Functions
# --------------------------
def sync_products(api_data: Dict, cycle_code: str, account_number: str) -> Dict:
    """
    Sync products from API data to database.
    
    Args:
        api_data: API response data
        cycle_code: Cycle code for metadata
        account_number: Account number for metadata
    
    Returns:
        dict with sync statistics
    """
    stats = {
        "inserted": 0,
        "updated": 0,
        "errors": 0
    }
    
    if not api_data or "Products" not in api_data:
        print("⚠️  No Products data in API response")
        return stats
    
    products = api_data["Products"]
    print(f"\nProcessing {len(products)} products...")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    sync_timestamp = datetime.now().isoformat()
    
    for product in products:
        try:
            skuguid = product.get("SKUGUID")
            sku_name = product.get("SKUName")
            brand = product.get("Brand")
            
            if not skuguid:
                print(f"⚠️  Skipping product with no SKUGUID: {product}")
                stats["errors"] += 1
                continue
            
            # Extract CARTON and PACK data from Packings array
            carton_upc = None
            carton_suppressed = None
            carton_conversion = None
            carton_promotional = None
            
            pack_upc = None
            pack_suppressed = None
            pack_conversion = None
            pack_promotional = None
            
            packings = product.get("Packings", [])
            for packing in packings:
                uom = packing.get("UOM", "").upper()
                upc = packing.get("UPC")
                suppressed = packing.get("SuppressedUPC")
                conversion = packing.get("ConversionFactor")
                promotional = packing.get("IsPromotionalUPC", "N")
                
                # Convert "N/A" to None
                if suppressed == "N/A":
                    suppressed = None
                
                if uom == "CARTON":
                    carton_upc = upc
                    carton_suppressed = suppressed
                    carton_conversion = conversion
                    carton_promotional = promotional
                elif uom == "PACK":
                    pack_upc = upc
                    pack_suppressed = suppressed
                    pack_conversion = conversion
                    pack_promotional = promotional
            
            # Check if product already exists
            cursor.execute("SELECT id FROM products WHERE SKUGUID = ?", (skuguid,))
            existing = cursor.fetchone()
            
            if existing:
                # Update existing product
                cursor.execute("""
                    UPDATE products 
                    SET SKUName = ?, Brand = ?,
                        CARTON_UPC = ?, CARTON_SuppressedUPC = ?, CARTON_ConversionFactor = ?, CARTON_IsPromotionalUPC = ?,
                        PACK_UPC = ?, PACK_SuppressedUPC = ?, PACK_ConversionFactor = ?, PACK_IsPromotionalUPC = ?,
                        api_cycle_code = ?, api_account_number = ?, api_last_synced = ?
                    WHERE SKUGUID = ?
                """, (
                    sku_name, brand,
                    carton_upc, carton_suppressed, carton_conversion, carton_promotional,
                    pack_upc, pack_suppressed, pack_conversion, pack_promotional,
                    cycle_code, account_number, sync_timestamp,
                    skuguid
                ))
                stats["updated"] += 1
                print(f"  ✅ Updated: {sku_name} ({skuguid})")
            else:
                # Insert new product
                cursor.execute("""
                    INSERT INTO products (
                        SKUGUID, SKUName, Brand,
                        CARTON_UPC, CARTON_SuppressedUPC, CARTON_ConversionFactor, CARTON_IsPromotionalUPC,
                        PACK_UPC, PACK_SuppressedUPC, PACK_ConversionFactor, PACK_IsPromotionalUPC,
                        api_cycle_code, api_account_number, api_last_synced
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    skuguid, sku_name, brand,
                    carton_upc, carton_suppressed, carton_conversion, carton_promotional,
                    pack_upc, pack_suppressed, pack_conversion, pack_promotional,
                    cycle_code, account_number, sync_timestamp
                ))
                stats["inserted"] += 1
                print(f"  ✅ Inserted: {sku_name} ({skuguid})")
        
        except Exception as e:
            print(f"  ❌ Error processing product {product.get('SKUGUID', 'unknown')}: {e}")
            stats["errors"] += 1
    
    conn.commit()
    conn.close()
    
    return stats


def sync_allowances(api_data: Dict, cycle_code: str, account_number: str) -> Dict:
    """
    Sync allowances from API data to database.
    
    Args:
        api_data: API response data
        cycle_code: Cycle code for metadata
        account_number: Account number for metadata
    
    Returns:
        dict with sync statistics
    """
    stats = {
        "inserted": 0,
        "updated": 0,
        "errors": 0
    }
    
    if not api_data or "LoyaltyAllowances" not in api_data:
        print("⚠️  No LoyaltyAllowances data in API response")
        return stats
    
    allowances = api_data["LoyaltyAllowances"]
    print(f"\nProcessing {len(allowances)} allowances...")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    sync_timestamp = datetime.now().isoformat()
    
    for allowance in allowances:
        try:
            allowance_type = allowance.get("AllowanceType")
            rcn_list = allowance.get("RCN", [])
            skuguid_list = allowance.get("SKUGUID", [])
            eligible_uom = allowance.get("EligibleUOM", [])
            min_quantity = allowance.get("MinimumQuantity")
            max_per_transaction = allowance.get("MaximumAllowancePerTransaction")
            max_daily_transactions = allowance.get("MaximumDailyTransactionsPerLoyalty")
            manufacturer_funded = allowance.get("ManufacturerFundedAmount")
            promotion_code = allowance.get("LoyaltyFundPromotionCode")
            promotional_upcs = allowance.get("PromotionalUPCsEligible", "N")
            
            # Get allowance details (first one in Allowances array)
            allowance_details = allowance.get("Allowances", [])
            if allowance_details:
                detail = allowance_details[0]
                currency = detail.get("Currency", "USD")
                amount = detail.get("Amount")
                start_date = detail.get("StartDate")
                end_date = detail.get("EndDate")
                change_from_prior = detail.get("ChangeFromPriorPeriod", 0.0)
            else:
                currency = "USD"
                amount = None
                start_date = None
                end_date = None
                change_from_prior = 0.0
            
            # Convert lists to comma-separated strings
            rcn_str = ",".join(rcn_list) if rcn_list else None
            eligible_uom_str = ",".join(eligible_uom) if eligible_uom else None
            
            # Check if allowance already exists (by promotion code and cycle)
            cursor.execute("""
                SELECT id FROM loyalty_allowances 
                WHERE LoyaltyFundPromotionCode = ? AND api_cycle_code = ?
            """, (promotion_code, cycle_code))
            existing = cursor.fetchone()
            
            if existing:
                allowance_id = existing[0]
                # Update existing allowance
                cursor.execute("""
                    UPDATE loyalty_allowances 
                    SET AllowanceType = ?, RCN = ?, EligibleUOM = ?,
                        MinimumQuantity = ?, MaximumAllowancePerTransaction = ?,
                        MaximumDailyTransactionsPerLoyalty = ?, ManufacturerFundedAmount = ?,
                        PromotionalUPCsEligible = ?, Currency = ?, Amount = ?,
                        StartDate = ?, EndDate = ?, ChangeFromPriorPeriod = ?,
                        api_account_number = ?, api_last_synced = ?
                    WHERE id = ?
                """, (
                    allowance_type, rcn_str, eligible_uom_str,
                    min_quantity, max_per_transaction, max_daily_transactions,
                    manufacturer_funded, promotional_upcs, currency, amount,
                    start_date, end_date, change_from_prior,
                    account_number, sync_timestamp,
                    allowance_id
                ))
                stats["updated"] += 1
                
                # Update SKU mappings
                cursor.execute("DELETE FROM loyalty_allowance_skus WHERE allowance_id = ?", (allowance_id,))
                for skuguid in skuguid_list:
                    cursor.execute("""
                        INSERT OR IGNORE INTO loyalty_allowance_skus (allowance_id, SKUGUID)
                        VALUES (?, ?)
                    """, (allowance_id, skuguid))
                
                print(f"  ✅ Updated allowance: {promotion_code}")
            else:
                # Insert new allowance
                cursor.execute("""
                    INSERT INTO loyalty_allowances (
                        AllowanceType, RCN, EligibleUOM,
                        MinimumQuantity, MaximumAllowancePerTransaction,
                        MaximumDailyTransactionsPerLoyalty, ManufacturerFundedAmount,
                        LoyaltyFundPromotionCode, PromotionalUPCsEligible,
                        Currency, Amount, StartDate, EndDate, ChangeFromPriorPeriod,
                        api_cycle_code, api_account_number, api_last_synced
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    allowance_type, rcn_str, eligible_uom_str,
                    min_quantity, max_per_transaction, max_daily_transactions,
                    manufacturer_funded, promotion_code, promotional_upcs,
                    currency, amount, start_date, end_date, change_from_prior,
                    cycle_code, account_number, sync_timestamp
                ))
                allowance_id = cursor.lastrowid
                stats["inserted"] += 1
                
                # Insert SKU mappings
                for skuguid in skuguid_list:
                    cursor.execute("""
                        INSERT INTO loyalty_allowance_skus (allowance_id, SKUGUID)
                        VALUES (?, ?)
                    """, (allowance_id, skuguid))
                
                print(f"  ✅ Inserted allowance: {promotion_code} ({len(skuguid_list)} SKUs)")
        
        except Exception as e:
            print(f"  ❌ Error processing allowance: {e}")
            import traceback
            traceback.print_exc()
            stats["errors"] += 1
    
    conn.commit()
    conn.close()
    
    return stats


# --------------------------
# Main Sync Function
# --------------------------
def sync_agdc_data(operating_company: str = None, cycle_code: str = None, account_number: str = None, bearer_token: str = None):
    """
    Main function to sync AGDC API data to database.
    
    Args:
        operating_company: Operating company code (defaults to API_PARAMS)
        cycle_code: Cycle code (defaults to API_PARAMS)
        account_number: Account number (defaults to API_PARAMS)
        bearer_token: Bearer token (if None, will fetch automatically)
    """
    # Use provided params or defaults
    op_company = operating_company or API_PARAMS["operatingCompany"]
    cycle = cycle_code or API_PARAMS["cycleCode"]
    account = account_number or API_PARAMS["accountNumber"]
    
    print("=" * 80)
    print("AGDC API Sync")
    print("=" * 80)
    print(f"Operating Company: {op_company}")
    print(f"Cycle Code: {cycle}")
    print(f"Account Number: {account}")
    print(f"Ocp-Apim-Subscription-Key: {OCP_APIM_SUBSCRIPTION_KEY}")
    print("=" * 80)
    
    # Get bearer token if not provided
    if not bearer_token:
        bearer_token = get_bearer_token()
        if not bearer_token:
            print("❌ Failed to obtain Bearer token. Cannot proceed.")
            return
    
    # Fetch data from API
    api_data = fetch_agdc_data(op_company, cycle, account, bearer_token)
    
    if not api_data:
        print("❌ Failed to fetch data from API. Exiting.")
        return
    
    # Extract first item from array (API returns array with one item)
    if isinstance(api_data, list) and len(api_data) > 0:
        api_data = api_data[0]
    
    # Sync products
    print("\n" + "=" * 80)
    print("SYNCING PRODUCTS")
    print("=" * 80)
    product_stats = sync_products(api_data, cycle, account)
    print(f"\nProducts: {product_stats['inserted']} inserted, {product_stats['updated']} updated, {product_stats['errors']} errors")
    
    # Sync allowances
    print("\n" + "=" * 80)
    print("SYNCING ALLOWANCES")
    print("=" * 80)
    allowance_stats = sync_allowances(api_data, cycle, account)
    print(f"\nAllowances: {allowance_stats['inserted']} inserted, {allowance_stats['updated']} updated, {allowance_stats['errors']} errors")
    
    # Note: Loyalty discount amounts come from loyalty_allowances.MaximumAllowancePerTransaction
    # No separate loyalty_discount_rules table needed.
    
    # Summary
    print("\n" + "=" * 80)
    print("SYNC COMPLETE")
    print("=" * 80)
    print(f"Products: {product_stats['inserted'] + product_stats['updated']} total")
    print(f"Allowances: {allowance_stats['inserted'] + allowance_stats['updated']} total")
    print("=" * 80)


if __name__ == "__main__":
    import sys
    import os
    
    # Check for OAuth credentials in environment variables (alternative to hardcoding)
    env_client_id = os.environ.get("OAUTH_CLIENT_ID")
    env_client_secret = os.environ.get("OAUTH_CLIENT_SECRET")
    
    # Update module-level variables (no global needed at module level)
    if env_client_id:
        OAUTH_CLIENT_ID = env_client_id
        print(f"ℹ️  Using OAUTH_CLIENT_ID from environment variable")
    if env_client_secret:
        OAUTH_CLIENT_SECRET = env_client_secret
        print(f"ℹ️  Using OAUTH_CLIENT_SECRET from environment variable")
    
    # Allow command-line arguments
    if len(sys.argv) >= 4:
        operating_company = sys.argv[1]
        cycle_code = sys.argv[2]
        account_number = sys.argv[3]
        # 4th argument can be bearer token (if you already have one)
        bearer_token = sys.argv[4] if len(sys.argv) >= 5 else None
        sync_agdc_data(operating_company, cycle_code, account_number, bearer_token)
    else:
        # Use default parameters
        sync_agdc_data()