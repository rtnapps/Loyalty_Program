#!/usr/bin/env python3
"""
Enable WAL mode on existing SQLite database for better performance.

WAL (Write-Ahead Logging) mode allows:
- Concurrent reads during writes
- Faster commits (especially for UPDATE operations)
- Better performance for phone number transactions

Run this script once to enable WAL mode on your existing database.
"""

import sqlite3
import os

DB_FILE = "loyalty.db"

def enable_wal_mode():
    """Enable WAL mode on the database"""
    if not os.path.exists(DB_FILE):
        print(f"❌ Database file '{DB_FILE}' not found!")
        print("   Please run 'python init_database.py' first to create the database.")
        return False
    
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        # Check current journal mode
        cursor.execute("PRAGMA journal_mode")
        current_mode = cursor.fetchone()[0]
        print(f"Current journal mode: {current_mode}")
        
        if current_mode.upper() == "WAL":
            print("✅ WAL mode is already enabled!")
            conn.close()
            return True
        
        # Enable WAL mode
        cursor.execute("PRAGMA journal_mode=WAL")
        new_mode = cursor.fetchone()[0]
        
        if new_mode.upper() == "WAL":
            print("✅ Successfully enabled WAL mode!")
            
            # Set other performance optimizations
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=10000")
            
            conn.close()
            print("\n📊 Performance optimizations enabled:")
            print("   - WAL mode: Enabled (allows concurrent reads during writes)")
            print("   - Synchronous: NORMAL (balance between safety and speed)")
            print("   - Busy timeout: 10000ms (10 seconds)")
            print("\n💡 This should significantly improve phone number transaction performance!")
            return True
        else:
            print(f"⚠️  Warning: Could not enable WAL mode. Current mode: {new_mode}")
            print("   This might be due to:")
            print("   - Database is locked by another process")
            print("   - SQLite version doesn't support WAL mode")
            print("   - Database file permissions issue")
            conn.close()
            return False
            
    except sqlite3.Error as e:
        print(f"❌ SQLite error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


if __name__ == "__main__":
    print("=" * 60)
    print("Enable WAL Mode for SQLite Database")
    print("=" * 60)
    print()
    
    success = enable_wal_mode()
    
    if success:
        print("\n" + "=" * 60)
        print("Next steps:")
        print("1. Restart your loyalty server")
        print("2. Test phone number transactions - they should be faster now!")
        print("=" * 60)
    else:
        print("\n❌ Failed to enable WAL mode. Please check the errors above.")