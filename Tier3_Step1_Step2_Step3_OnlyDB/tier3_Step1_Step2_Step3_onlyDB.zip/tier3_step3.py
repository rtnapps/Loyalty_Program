#!/usr/bin/env python3
"""
Tier 3 Rules Engine - Step 3: Normalize the Basket (Clean the UPC List)

Per AGDC DTP Tier 3 requirements:
- Lookup product master data for each UPC (brand, manufacturer, category, unit_of_measure)
- Classify unknown UPCs as "unknown tobacco"
- Combine identical UPC rows only if same unit price (AGDC scan rules expect line integrity)
- Map unit of measure (pack vs carton, etc.)
"""

import sqlite3
import os
from typing import Dict, List, Optional, Callable, Tuple
from decimal import Decimal


# --------------------------
# Configuration
# --------------------------
# Database file path
DB_FILE = "loyalty.db"


# --------------------------
# Database Helper Functions
# --------------------------
def get_db_connection():
    """Get SQLite database connection with timeout for concurrent access"""
    if not os.path.exists(DB_FILE):
        raise FileNotFoundError(f"Database file '{DB_FILE}' not found. Please run 'python init_database.py' first.")
    conn = sqlite3.connect(DB_FILE, timeout=10.0)  # 10 second timeout for concurrent access
    return conn


# --------------------------
# UPC Master Data Structure
# --------------------------
def get_upc_master_data(upc: str, logger: Optional[Callable[[str], None]] = None) -> Optional[Dict]:
    """
    Lookup UPC in master table to get product information.
    Searches both CARTON_UPC and PACK_UPC columns.
    
    Args:
        upc: The UPC code to lookup
        logger: Optional logging function
    
    Returns:
        dict with keys: SKUGUID, SKUName, Brand, manufacturer, category, 
                       unit_of_measure (CARTON or PACK), program_eligibility,
                       and UPC-specific fields (CARTON_* or PACK_*)
        or None if UPC not found
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not upc or not upc.strip():
        log(f"get_upc_master_data: Empty UPC provided")
        return None
    
    upc = upc.strip()
    log(f"get_upc_master_data: Looking up UPC='{upc}'")
    
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Search in both CARTON_UPC and PACK_UPC columns (including suppressed UPCs)
        cursor.execute("""
            SELECT SKUGUID, SKUName, Brand, manufacturer, category, program_eligibility,
                   CARTON_UPC, CARTON_SuppressedUPC, CARTON_ConversionFactor, CARTON_IsPromotionalUPC,
                   PACK_UPC, PACK_SuppressedUPC, PACK_ConversionFactor, PACK_IsPromotionalUPC,
                   created_at, updated_at
            FROM products 
            WHERE CARTON_UPC = ? OR PACK_UPC = ? OR CARTON_SuppressedUPC = ? OR PACK_SuppressedUPC = ?
            LIMIT 1
        """, (upc, upc, upc, upc))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            # Determine if this is a CARTON or PACK UPC
            unit_of_measure = None
            matched_upc_type = None
            
            if row["CARTON_UPC"] and row["CARTON_UPC"].strip() == upc:
                unit_of_measure = "CARTON"
                matched_upc_type = "CARTON"
            elif row["PACK_UPC"] and row["PACK_UPC"].strip() == upc:
                unit_of_measure = "PACK"
                matched_upc_type = "PACK"
            elif row["CARTON_SuppressedUPC"] and row["CARTON_SuppressedUPC"].strip() == upc:
                unit_of_measure = "CARTON"
                matched_upc_type = "CARTON_SUPPRESSED"
            elif row["PACK_SuppressedUPC"] and row["PACK_SuppressedUPC"].strip() == upc:
                unit_of_measure = "PACK"
                matched_upc_type = "PACK_SUPPRESSED"
            
            result = {
                "SKUGUID": row["SKUGUID"],
                "SKUName": row["SKUName"],
                "Brand": row["Brand"],
                "manufacturer": row["manufacturer"],
                "category": row["category"],  # CIG, MST, CIGAR, ONP, etc.
                "unit_of_measure": unit_of_measure,  # CARTON or PACK
                "program_eligibility": row["program_eligibility"],  # ATOC, Other, etc.
                "matched_upc_type": matched_upc_type,
                # CARTON fields
                "CARTON_UPC": row["CARTON_UPC"],
                "CARTON_SuppressedUPC": row["CARTON_SuppressedUPC"],
                "CARTON_ConversionFactor": row["CARTON_ConversionFactor"],
                "CARTON_IsPromotionalUPC": row["CARTON_IsPromotionalUPC"],  # "Y" or "N" from API
                # PACK fields
                "PACK_UPC": row["PACK_UPC"],
                "PACK_SuppressedUPC": row["PACK_SuppressedUPC"],
                "PACK_ConversionFactor": row["PACK_ConversionFactor"],
                "PACK_IsPromotionalUPC": row["PACK_IsPromotionalUPC"],  # "Y" or "N" from API
            }
            log(f"get_upc_master_data: ✅ Found UPC in master table")
            log(f"get_upc_master_data:   - SKUGUID: {result['SKUGUID']}")
            log(f"get_upc_master_data:   - SKUName: {result['SKUName']}")
            log(f"get_upc_master_data:   - Brand: {result['Brand']}")
            log(f"get_upc_master_data:   - manufacturer: {result['manufacturer']}")
            log(f"get_upc_master_data:   - category: {result['category']}")
            log(f"get_upc_master_data:   - unit_of_measure: {result['unit_of_measure']}")
            log(f"get_upc_master_data:   - matched_upc_type: {result['matched_upc_type']}")
            log(f"get_upc_master_data:   - program_eligibility: {result['program_eligibility']}")
            return result
        else:
            log(f"get_upc_master_data: ❌ UPC not found in products table (searched CARTON_UPC, PACK_UPC, CARTON_SuppressedUPC, PACK_SuppressedUPC)")
            return None
    except Exception as e:
        log(f"get_upc_master_data: ❌ DATABASE ERROR: {e}")
        import traceback
        log(f"get_upc_master_data:   - Traceback: {traceback.format_exc()}")
        return None


# --------------------------
# Transaction Line Structure
# --------------------------
def normalize_basket(
    transaction_lines: List[Dict],
    logger: Optional[Callable[[str], None]] = None
) -> Dict:
    """
    Step 3: Normalize the basket (clean the UPC list).
    
    For each UPC:
    - Lookup product master (brand, manufacturer, category, unit_of_measure)
    - Classify unknown UPCs as "unknown tobacco"
    - Combine identical UPC rows only if same unit price (AGDC scan rules expect line integrity)
    
    Args:
        transaction_lines: List of dicts with keys:
            - upc: UPC code
            - quantity: Quantity
            - unit_price: Unit price (regular price)
            - line_number: Line number in transaction
            - description: Item description (optional)
        logger: Optional logging function
    
    Returns dict with:
    - normalized_lines: List of normalized line items
    - unknown_upcs: List of UPCs not found in master table
    - total_lines: Total number of lines after normalization
    - combined_lines: Number of lines that were combined
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    log(f"normalize_basket: ========== START BASKET NORMALIZATION ==========")
    log(f"normalize_basket: Input - {len(transaction_lines)} transaction lines")
    
    result = {
        "normalized_lines": [],
        "unknown_upcs": [],
        "total_lines": 0,
        "combined_lines": 0,
        "errors": []
    }
    
    if not transaction_lines:
        log(f"normalize_basket: No transaction lines provided")
        return result
    
    # Step 1: Lookup each UPC in master table
    upc_data_cache = {}  # Cache lookups to avoid duplicate queries
    normalized_lines = []
    
    for idx, line in enumerate(transaction_lines):
        upc = line.get("upc", "").strip() if line.get("upc") else ""
        quantity = line.get("quantity", 1)
        unit_price = line.get("unit_price", "0")
        line_number = line.get("line_number", str(idx + 1))
        description = line.get("description", "")
        
        log(f"normalize_basket: Processing line {idx + 1}: UPC='{upc}', Qty={quantity}, Price={unit_price}")
        
        if not upc:
            log(f"normalize_basket: ⚠️  Line {idx + 1} has no UPC - skipping")
            result["errors"].append(f"Line {line_number}: Missing UPC")
            continue
        
        # Lookup UPC in master table (use cache if available)
        if upc not in upc_data_cache:
            upc_data = get_upc_master_data(upc, logger=log)
            upc_data_cache[upc] = upc_data
        else:
            upc_data = upc_data_cache[upc]
        
        # Create normalized line item
        normalized_line = {
            "upc": upc,
            "quantity": quantity,
            "unit_price": unit_price,
            "line_number": line_number,
            "description": description,
            "SKUGUID": upc_data["SKUGUID"] if upc_data else None,
            "SKUName": upc_data["SKUName"] if upc_data else None,
            "Brand": upc_data["Brand"] if upc_data else None,
            "manufacturer": upc_data["manufacturer"] if upc_data else None,
            "category": upc_data["category"] if upc_data else "UNKNOWN_TOBACCO",
            "unit_of_measure": upc_data["unit_of_measure"] if upc_data else None,  # CARTON or PACK
            "program_eligibility": upc_data["program_eligibility"] if upc_data else None,
            "matched_upc_type": upc_data["matched_upc_type"] if upc_data else None,
            # CARTON fields
            "CARTON_UPC": upc_data["CARTON_UPC"] if upc_data else None,
            "CARTON_SuppressedUPC": upc_data["CARTON_SuppressedUPC"] if upc_data else None,
            "CARTON_ConversionFactor": upc_data["CARTON_ConversionFactor"] if upc_data else None,
            "CARTON_IsPromotionalUPC": upc_data["CARTON_IsPromotionalUPC"] if upc_data else "N",
            # PACK fields
            "PACK_UPC": upc_data["PACK_UPC"] if upc_data else None,
            "PACK_SuppressedUPC": upc_data["PACK_SuppressedUPC"] if upc_data else None,
            "PACK_ConversionFactor": upc_data["PACK_ConversionFactor"] if upc_data else None,
            "PACK_IsPromotionalUPC": upc_data["PACK_IsPromotionalUPC"] if upc_data else "N",
            "is_unknown": upc_data is None,
        }
        
        if upc_data is None:
            log(f"normalize_basket: ⚠️  UPC '{upc}' not found in master table - classifying as 'unknown tobacco'")
            result["unknown_upcs"].append(upc)
        
        normalized_lines.append(normalized_line)
    
    log(f"normalize_basket: Lookup complete - {len(normalized_lines)} lines processed, {len(result['unknown_upcs'])} unknown UPCs")
    
    # Step 2: Combine identical UPC rows only if same unit price
    # AGDC scan rules expect line integrity - only combine if same price
    combined_lines = []
    seen_upc_price = {}  # Track (UPC, price) combinations
    
    for line in normalized_lines:
        upc = line["upc"]
        unit_price = line["unit_price"]
        key = (upc, unit_price)
        
        if key in seen_upc_price:
            # Combine with existing line (same UPC and price)
            existing_idx = seen_upc_price[key]
            existing_line = combined_lines[existing_idx]
            existing_line["quantity"] = int(existing_line["quantity"]) + int(line["quantity"])
            log(f"normalize_basket: Combined line - UPC='{upc}', Price={unit_price}, Total Qty={existing_line['quantity']}")
            result["combined_lines"] += 1
        else:
            # New line (different UPC or price)
            combined_lines.append(line.copy())
            seen_upc_price[key] = len(combined_lines) - 1
    
    result["normalized_lines"] = combined_lines
    result["total_lines"] = len(combined_lines)
    
    log(f"normalize_basket: ========== NORMALIZATION COMPLETE ==========")
    log(f"normalize_basket: Total lines: {result['total_lines']}")
    log(f"normalize_basket: Combined lines: {result['combined_lines']}")
    log(f"normalize_basket: Unknown UPCs: {len(result['unknown_upcs'])}")
    if result["unknown_upcs"]:
        log(f"normalize_basket: Unknown UPCs: {', '.join(result['unknown_upcs'])}")
    
    return result


# --------------------------
# Helper Functions
# --------------------------
def extract_transaction_lines_from_xml(root, logger: Optional[Callable[[str], None]] = None) -> List[Dict]:
    """
    Extract transaction lines from GetRewardsRequest XML.
    
    Args:
        root: XML ElementTree root element
        logger: Optional logging function
    
    Returns:
        List of dicts with transaction line data
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    lines = []
    transaction_lines = root.findall(".//TransactionLine")
    
    log(f"extract_transaction_lines_from_xml: Found {len(transaction_lines)} TransactionLine elements")
    
    for tx_line in transaction_lines:
        item_line = tx_line.find("ItemLine")
        if item_line is None:
            continue
        
        # Extract line number
        line_num_elem = tx_line.find("LineNumber")
        line_number = line_num_elem.text.strip() if line_num_elem is not None and line_num_elem.text else "1"
        
        # Extract UPC
        upc_elem = item_line.find(".//ItemCode/POSCode")
        upc = upc_elem.text.strip() if upc_elem is not None and upc_elem.text else ""
        
        # Extract quantity
        qty_elem = item_line.find(".//Quantity")
        quantity = qty_elem.text.strip() if qty_elem is not None and qty_elem.text else "1"
        
        # Extract unit price
        price_elem = item_line.find(".//RegularUnitPrice")
        if price_elem is None:
            price_elem = item_line.find(".//ExtendedPrice")
        unit_price = price_elem.text.strip() if price_elem is not None and price_elem.text else "0"
        
        # Extract description
        desc_elem = item_line.find(".//Description")
        description = desc_elem.text.strip() if desc_elem is not None and desc_elem.text else ""
        
        if upc:  # Only add lines with UPC
            lines.append({
                "upc": upc,
                "quantity": quantity,
                "unit_price": unit_price,
                "line_number": line_number,
                "description": description
            })
            log(f"extract_transaction_lines_from_xml: Line {line_number}: UPC='{upc}', Qty={quantity}, Price={unit_price}")
    
    return lines


# --------------------------
# Allowance Lookup Functions
# --------------------------
def get_allowance_for_sku(skuguid: str, logger: Optional[Callable[[str], None]] = None) -> Optional[Dict]:
    """
    Get loyalty allowance information for a SKU.
    
    Args:
        skuguid: The SKUGUID to lookup
        logger: Optional logging function
    
    Returns:
        dict with allowance details, or None if not found
    """
    def log(msg: str):
        if logger:
            logger(msg)
    
    if not skuguid or not skuguid.strip():
        log(f"get_allowance_for_sku: Empty SKUGUID provided")
        return None
    
    skuguid = skuguid.strip()
    log(f"get_allowance_for_sku: Looking up allowance for SKUGUID='{skuguid}'")
    
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Find allowance that includes this SKUGUID
        cursor.execute("""
            SELECT la.*
            FROM loyalty_allowances la
            INNER JOIN loyalty_allowance_skus las ON la.id = las.allowance_id
            WHERE las.SKUGUID = ?
            AND la.StartDate <= DATE('now')
            AND la.EndDate >= DATE('now')
            LIMIT 1
        """, (skuguid,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            result = {
                "AllowanceType": row["AllowanceType"],
                "RCN": row["RCN"],
                "EligibleUOM": row["EligibleUOM"],
                "MinimumQuantity": row["MinimumQuantity"],
                "MaximumAllowancePerTransaction": row["MaximumAllowancePerTransaction"],
                "MaximumDailyTransactionsPerLoyalty": row["MaximumDailyTransactionsPerLoyalty"],
                "ManufacturerFundedAmount": row["ManufacturerFundedAmount"],
                "LoyaltyFundPromotionCode": row["LoyaltyFundPromotionCode"],
                "PromotionalUPCsEligible": row["PromotionalUPCsEligible"],
                "Currency": row["Currency"],
                "Amount": row["Amount"],
                "StartDate": row["StartDate"],
                "EndDate": row["EndDate"],
                "ChangeFromPriorPeriod": row["ChangeFromPriorPeriod"],
            }
            log(f"get_allowance_for_sku: ✅ Found allowance for SKUGUID")
            log(f"get_allowance_for_sku:   - Promotion Code: {result['LoyaltyFundPromotionCode']}")
            log(f"get_allowance_for_sku:   - Amount: {result['Amount']}")
            log(f"get_allowance_for_sku:   - Valid: {result['StartDate']} to {result['EndDate']}")
            return result
        else:
            log(f"get_allowance_for_sku: ❌ No active allowance found for SKUGUID")
            return None
    except Exception as e:
        log(f"get_allowance_for_sku: ❌ DATABASE ERROR: {e}")
        import traceback
        log(f"get_allowance_for_sku:   - Traceback: {traceback.format_exc()}")
        return None